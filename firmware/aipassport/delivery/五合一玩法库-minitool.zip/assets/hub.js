/* 五合一玩法库 · launcher */
(function () {
  "use strict";
  var MODS = [
    { k: "m307", g: "☯", n: "易经口袋", d: "64 卦全典 · 时间起卦 · 铜钱摇卦 · 八字排盘", t: "玄学" },
    { k: "m303", g: "✶", n: "玄学口袋", d: "每日一卦 · 卦象详解 · 收藏与历史记录", t: "玄学" },
    { k: "m316", g: "☷", n: "紫微六层叠盘", d: "命宫十二宫 · 大限/流年/流月/流日/流时", t: "命理" },
    { k: "m332", g: "◍", n: "六分之一轮盘", d: "装弹 · 转膛 · 扣扳机 · 概率与决断", t: "博弈" },
    { k: "m386", g: "✦", n: "宇宙浪漫", d: "星海巡航 · 落入爱的黑洞 · REBORN", t: "放空" }
  ];
  var hub = document.getElementById("hub");
  var grid = document.getElementById("hbGrid");
  var cur = null;

  var h = "";
  for (var i = 0; i < MODS.length; i++) {
    var m = MODS[i];
    h += "<button class=\"hb-card\" type=\"button\" data-k=\"" + m.k + "\">" +
      "<div class=\"g\">" + m.g + "</div><b>" + m.n + "</b><span>" + m.d + "</span><i>" + m.t + "</i></button>";
  }
  h += "<div class=\"hb-card wide\" style=\"pointer-events:none\"><div class=\"g\">☰</div><b>五个玩法，一个口袋</b>" +
    "<span>点上面任意卡片进入；每个玩法都有自己独立的存档、历史与收集进度。回到本页只需点左上角「‹ 玩法库」。</span><i>本地运行 · 零网络</i></div>";
  grid.innerHTML = h;

  function show(k) {
    hub.style.display = "none";
    var el = document.getElementById(k);
    if (el) { el.style.display = "block"; }
    cur = k;
    window.scrollTo(0, 0);
    /* 让模块重算画布/布局尺寸 */
    setTimeout(function () { window.dispatchEvent(new Event("resize")); }, 30);
  }
  function back() {
    if (cur) {
      var el = document.getElementById(cur);
      if (el) { el.style.display = "none"; }
      cur = null;
    }
    hub.style.display = "block";
    window.scrollTo(0, 0);
  }
  grid.addEventListener("click", function (e) {
    var b = e.target.closest("[data-k]");
    if (b) { show(b.getAttribute("data-k")); }
  });
  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-back]")) { back(); }
  });
  window.HUB = { show: show, back: back };
})();
