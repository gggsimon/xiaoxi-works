(function(){
  var PFX="m332-";
  function Q(id){ return document.getElementById(PFX+id); }
/* 六分之一轮盘（原「俄罗斯轮盘」）· 移动端原生版
 * 规则严格还原固件：开膛装弹 → 转膛 → 随机定格 → 扣扳机 → 空枪弹膛递进 → 六发内必响
 * 移动端新增：触控甩动转轮、收手离场（决断）、条件概率实时提示、战绩与统计持久化、结果卡分享
 */
(function () {
  "use strict";
  var A = window.AAPT;
  var S_INTRO = "intro", S_LOAD = "load", S_SPIN = "spin", S_AIM = "aim", S_OVER = "over", S_QUIT = "quit";
  var st = S_INTRO;
  var bullet = -1, cursor = 0, pointer = 0, shots = 0;
  var rot = 0, vel = 900, spinning = false, stopping = false, paused = false;
  var rafId = 0, lastT = 0;
  var lastRound = null;
  var STATS = { g: 0, w: 0, best: 0 };
  var HIST = [];

  var cv = Q("cv");
  var x = cv.getContext("2d");
  var S = 300, cx = 150, cy = 160, R = 100;

  /* ---------------- 几何与绘制 ---------------- */
  function D2R(d) { return d * Math.PI / 180; }
  function disc(g, px, py, r, col) {
    if (r <= 0) { return; }
    g.beginPath(); g.arc(px, py, r, 0, Math.PI * 2); g.fillStyle = col; g.fill();
  }
  function ring(g, px, py, r, col, w) {
    if (r <= 0) { return; }
    g.beginPath(); g.arc(px, py, r, 0, Math.PI * 2); g.strokeStyle = col; g.lineWidth = w; g.stroke();
  }
  function arcSeg(g, px, py, r, col, w, a0, a1) {
    if (r <= 0) { return; }
    g.beginPath(); g.arc(px, py, r, a0, a1); g.strokeStyle = col; g.lineWidth = w; g.lineCap = "butt"; g.stroke();
  }
  function chamberXY(i, rr, angBase) {
    var a = D2R(angBase + i * 60);
    return { px: cx + rr * Math.cos(a), py: cy + rr * Math.sin(a) };
  }

  function drawBarrel(g) {
    var bot = cy - R - R * 0.12;
    var w = R * 0.22;
    g.fillStyle = "#4a515a"; g.fillRect(cx - w / 2, 1, w, bot - 2);
    g.fillStyle = "#7b838c"; g.fillRect(cx - w / 2 + 1.5, 2, w * 0.26, bot - 4);
    g.fillStyle = "#282b30"; g.fillRect(cx + w / 2 - 1.5 - w * 0.26, 2, w * 0.26, bot - 4);
    disc(g, cx, bot + R * 0.02, R * 0.17, "#6a717a");
    disc(g, cx, bot + R * 0.02, R * 0.11, "#101113");
    g.fillStyle = "#8f979e"; g.fillRect(cx - 1, 3, 2, R * 0.16);
  }

  /* 开膛：六个弹膛洞 */
  function drawOpen(g, reveal) {
    ring(g, cx, cy, R, "#9aa0a8", R * 0.11);
    disc(g, cx, cy, R - R * 0.055, "#3c464f");
    arcSeg(g, cx, cy, R - R * 0.10, "rgba(195,201,207,.55)", Math.max(1, R * 0.03), Math.PI, Math.PI * 1.8);
    var rc = R * 0.60, rh = R * 0.19;
    for (var i = 0; i < 6; i++) {
      var p = chamberXY(i, rc, -90);
      disc(g, p.px, p.py, rh, "#14161a");
      ring(g, p.px, p.py, rh + rh * 0.16, "#aeb4ba", Math.max(1.2, R * 0.032));
      if (i === bullet && (reveal || st === S_LOAD)) {
        disc(g, p.px, p.py, rh * 0.72, "#d7a33a");
        disc(g, p.px - rh * 0.22, p.py - rh * 0.24, rh * 0.22, "#f0d18a");
      }
      if (i === cursor && st === S_LOAD) {
        ring(g, p.px, p.py, rh + rh * 0.44, "#e0c98a", Math.max(1.6, R * 0.045));
      }
      if (i === pointer && (st === S_AIM || st === S_OVER || st === S_QUIT)) {
        ring(g, p.px, p.py, rh + rh * 0.60, "#e0c98a", Math.max(1.4, R * 0.038));
      }
    }
    disc(g, cx, cy, R * 0.17, "#16181c");
    disc(g, cx, cy, R * 0.11, "#8f979e");
  }

  /* 闭膛：旋转盖面 */
  function drawClosed(g, r, aim) {
    ring(g, cx, cy, R, "#9aa0a8", R * 0.11);
    disc(g, cx, cy, R - R * 0.055, "#3c464f");
    arcSeg(g, cx, cy, R - R * 0.11, "#c3c9cf", Math.max(1, R * 0.035), Math.PI, Math.PI * 1.85);
    g.strokeStyle = "#0e0e10"; g.lineWidth = Math.max(1.4, R * 0.034); g.lineCap = "round";
    for (var i = 0; i < 6; i++) {
      var a = D2R(r + i * 60);
      g.beginPath();
      g.moveTo(cx + R * 0.55 * Math.cos(a), cy + R * 0.55 * Math.sin(a));
      g.lineTo(cx + R * 0.92 * Math.cos(a), cy + R * 0.92 * Math.sin(a));
      g.stroke();
    }
    if (aim) {
      arcSeg(g, cx, cy, R - R * 0.09, "#e0c98a", Math.max(2, R * 0.05), -Math.PI / 2 - 0.17, -Math.PI / 2 + 0.17);
    }
    disc(g, cx, cy, R * 0.17, "#16181c");
    disc(g, cx, cy, R * 0.11, "#8f979e");
    disc(g, cx, cy, R * 0.04, "#5d646c");
  }

  function draw() {
    x.clearRect(0, 0, S, S);
    var gd = x.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.6);
    gd.addColorStop(0, "rgba(224,201,138,.07)");
    gd.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = gd; x.fillRect(0, 0, S, S);
    drawBarrel(x);
    if (st === S_INTRO || st === S_LOAD) { drawOpen(x, false); }
    else if (st === S_OVER || st === S_QUIT) { drawOpen(x, true); }
    else { drawClosed(x, rot, st === S_AIM); }
  }

  function layout() {
    S = cv.clientWidth || 300;
    var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    cv.width = Math.round(S * dpr); cv.height = Math.round(S * dpr);
    x.setTransform(dpr, 0, 0, dpr, 0, 0);
    cx = S / 2; cy = S * 0.54; R = S * 0.33;
    draw();
  }

  /* ---------------- 动画 ---------------- */
  function loop(t) {
    rafId = requestAnimationFrame(loop);
    if (!lastT) { lastT = t; }
    var dt = (t - lastT) / 1000; lastT = t;
    if (dt > 0.1) { dt = 0.1; }
    if (spinning && !stopping && !paused) { rot += vel * dt; draw(); }
  }
  function easeOut(e) { return 1 - Math.pow(1 - e, 3); }
  function animateRot(delta, dur, done) {
    var start = rot;
    var t0 = (window.performance && performance.now) ? performance.now() : Date.now();
    stopping = true;
    (function step() {
      var now = (window.performance && performance.now) ? performance.now() : Date.now();
      var e = Math.min(1, (now - t0) / dur);
      rot = start + delta * easeOut(e);
      draw();
      if (e < 1) { requestAnimationFrame(step); }
      else { stopping = false; if (done) { done(); } }
    })();
  }
  function startSpin() {
    st = S_SPIN; spinning = true; stopping = false; paused = false;
    vel = 860 + Math.random() * 260;
    updateUI();
  }
  function stopSpin() {
    if (st !== S_SPIN || stopping) { return; }
    pointer = Math.floor(Math.random() * 6);
    var cur = ((rot % 360) + 360) % 360;
    var tgt = ((270 - pointer * 60) % 360 + 360) % 360;
    var d = ((tgt - cur) % 360 + 360) % 360;
    animateRot(d + 720, 1250, function () {
      spinning = false;
      st = S_AIM;
      A.buzz(20);
      updateUI();
    });
  }

  /* ---------------- 流程 ---------------- */
  function newGame() {
    bullet = -1; cursor = Math.floor(Math.random() * 6); shots = 0; lastRound = null;
    st = S_LOAD; spinning = false; stopping = false; paused = false;
    updateUI(); draw();
  }
  function loadAndSpin() {
    if (st !== S_LOAD) { return; }
    bullet = cursor; A.buzz(12);
    startSpin(); draw();
  }
  function fire() {
    if (st !== S_AIM) { return; }
    shots++;
    draw();
    if (pointer === bullet) {
      st = S_OVER; spinning = false;
      flashFx(); A.buzz([30, 40, 60]);
      finish(false);
    } else {
      A.buzz(14);
      animateRot(-60, 280, function () {
        pointer = (pointer + 1) % 6;
        st = S_AIM; updateUI();
      });
    }
  }
  function quit() {
    if (st !== S_AIM) { return; }
    st = S_QUIT; A.buzz(10);
    finish(true);
  }
  function finish(win) {
    var safe = win ? shots : shots - 1;
    var rec = { ts: Date.now(), b: bullet + 1, n: shots, win: win ? 1 : 0 };
    lastRound = rec;
    STATS.g += 1;
    if (win) { STATS.w += 1; }
    if (safe > STATS.best) { STATS.best = safe; }
    A.setJSON("rl_stats", STATS);
    A.pushHistory("rl_rounds", rec, 12, function (arr) { HIST = arr; renderHistory(); });
    renderStats();
    updateUI(); draw();
  }
  function flashFx() {
    var f = Q("flash");
    var s = Q("stage");
    f.className = "flash on";
    setTimeout(function () { f.className = "flash off"; }, 70);
    s.className = "stage shake";
    setTimeout(function () { s.className = "stage"; }, 420);
  }

  /* ---------------- UI ---------------- */
  var elTitle = Q("stTitle");
  var elStatus = Q("stStatus");
  var elHint = Q("stHint");
  var btnMain = Q("btnMain");
  var btnRand = Q("btnRand");
  var btnQuit = Q("btnQuit");
  var probRow = Q("probRow");
  var probTxt = Q("probTxt");

  function buildProbRow() {
    var h = "";
    for (var k = 1; k <= 6; k++) { h += "<i data-k=\"" + k + "\">" + k + "</i>"; }
    probRow.innerHTML = h;
  }
  function renderProb() {
    var cells = probRow.getElementsByTagName("i");
    var fired = shots;
    for (var i = 0; i < cells.length; i++) {
      var k = i + 1, c = "";
      if (st === S_OVER && k === fired) { c = "boom"; }
      else if (k <= fired) { c = "past"; }
      else if (k === fired + 1 && (st === S_AIM || st === S_LOAD || st === S_SPIN || st === S_INTRO)) { c = "cur"; }
      if ((st === S_OVER || st === S_QUIT) && k === bullet + 1) { c += " loaded"; }
      cells[i].className = c;
    }
    var nxt = fired + 1;
    if (st === S_INTRO) { probTxt.innerHTML = "每一发的命中概率都是 <b>1/6</b>"; }
    else if (st === S_OVER) { probTxt.innerHTML = "第 <b>" + fired + "</b> 发命中 · 概率 <b>1/" + (7 - fired) + "</b>"; }
    else if (st === S_QUIT) { probTxt.innerHTML = "收手于第 " + fired + " 发后 · 再一发概率 <b>1/" + (6 - fired) + "</b>"; }
    else if (nxt <= 6) { probTxt.innerHTML = "第 <b>" + nxt + "</b> 发 · 命中概率 <b>1/" + (7 - nxt) + "</b>"; }
    else { probTxt.innerHTML = "弹膛已空 · 概率 <b>1/1</b>"; }
  }

  function updateUI() {
    var t = "", s = "", h = "", m = "", mcls = "", disRand = true, disQuit = true;
    if (st === S_INTRO) {
      t = "俄罗斯轮盘"; s = "装弹 · 转膛 · 扣扳机"; h = "点下方按钮开始"; m = "开 始";
    } else if (st === S_LOAD) {
      t = "装弹"; s = "开膛 · 点选弹位放入子弹"; h = "点画面上的弹膛选位，或随机"; m = "装填并转膛"; disRand = false;
      t = "装弹 · 第 " + (cursor + 1) + " 格";
    } else if (st === S_SPIN) {
      t = "转动转轮"; s = "哗啦…哗啦…转动中"; h = "点画面或按钮随时叫停"; m = "停 止 转 轮";
    } else if (st === S_AIM) {
      t = shots === 0 ? "转轮已停" : "空枪 · 安全"; s = "第 " + (pointer + 1) + " 格对膛 · 已开 " + shots + " 发";
      h = "继续扣扳机，或见好就收"; m = "扣 扳 机"; mcls = "danger"; disQuit = false;
    } else if (st === S_OVER) {
      t = "中弹了"; s = "第 " + shots + " 发 · 第 " + (pointer + 1) + " 格对膛 · 子弹在第 " + (bullet + 1) + " 格";
      h = "六发之内必有一响"; m = "再 来 一 局"; mcls = "ghost";
    } else if (st === S_QUIT) {
      t = "收手 · 生还"; s = "连开 " + shots + " 发全身而退 · 子弹在第 " + (bullet + 1) + " 格";
      h = "敢开几发，也敢收手"; m = "再 来 一 局"; mcls = "ghost";
    }
    elTitle.textContent = t;
    elTitle.className = "st-t" + (st === S_OVER ? " hit" : (st === S_AIM && shots > 0 ? " safe" : ""));
    elStatus.textContent = s;
    elHint.textContent = h;
    btnMain.textContent = m;
    btnMain.className = "btn-main" + (mcls ? " " + mcls : "");
    btnRand.disabled = disRand;
    btnQuit.disabled = disQuit;
    btnRand.style.opacity = disRand ? ".35" : "1";
    btnQuit.style.opacity = disQuit ? ".35" : "1";
    renderProb();
    draw();
  }

  function fmt(ts) {
    var d = new Date(ts);
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return (d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }
  function renderHistory() {
    var list = Q("histList");
    var emp = Q("histEmpty");
    if (!HIST || !HIST.length) { list.innerHTML = ""; emp.className = "empty"; return; }
    emp.className = "empty hide";
    var h = "";
    for (var i = 0; i < HIST.length; i++) {
      var r = HIST[i];
      var head = r.win ? ("连开 <b>" + r.n + "</b> 发 · 收手生还") : ("第 <b>" + r.n + "</b> 发中弹");
      h += "<div class=\"hi" + (r.win ? "" : " hit") + "\"><div class=\"l1\">" + head +
        "</div><div class=\"l2\">子弹在第 " + r.b + " 格 · " + fmt(r.ts) + "</div></div>";
    }
    list.innerHTML = h;
  }
  function renderStats() {
    Q("sGames").textContent = STATS.g;
    Q("sSurv").textContent = STATS.w;
    Q("sBest").textContent = STATS.best;
    Q("sRate").textContent = STATS.g ? Math.round(STATS.w * 100 / STATS.g) + "%" : "—";
  }

  /* ---------------- 触控 ---------------- */
  var drag = null, suppressClick = false;
  function localAng(clX, clY) {
    var r = cv.getBoundingClientRect();
    return Math.atan2(clY - r.top - cy, clX - r.left - cx) * 180 / Math.PI;
  }
  function localXY(clX, clY) {
    var r = cv.getBoundingClientRect();
    return { px: clX - r.left, py: clY - r.top };
  }
  function pickChamber(clX, clY) {
    var p = localXY(clX, clY);
    var rc = R * 0.60, best = -1, bd = 1e9;
    for (var i = 0; i < 6; i++) {
      var q = chamberXY(i, rc, -90);
      var d = Math.sqrt((p.px - q.px) * (p.px - q.px) + (p.py - q.py) * (p.py - q.py));
      if (d < bd) { bd = d; best = i; }
    }
    return (bd <= R * 0.42) ? best : -1;
  }
  function onTap(clX, clY) {
    if (st === S_LOAD) {
      var i = pickChamber(clX, clY);
      if (i >= 0) { cursor = i; A.buzz(8); updateUI(); draw(); }
      return;
    }
    if (st === S_SPIN) { stopSpin(); return; }
    if (st === S_AIM) { fire(); return; }
  }
  A.tap(cv, function (e) {
    if (suppressClick) { suppressClick = false; return; }
    onTap(e.clientX, e.clientY);
  });
  cv.addEventListener("touchstart", function (e) {
    if (st !== S_SPIN || !e.touches || !e.touches.length) { return; }
    var t0 = e.touches[0];
    drag = { a: localAng(t0.clientX, t0.clientY), moved: 0, v: 0, t: Date.now() };
    paused = true;
  }, { passive: true });
  cv.addEventListener("touchmove", function (e) {
    if (!drag || !e.touches || !e.touches.length) { return; }
    var t0 = e.touches[0];
    var a = localAng(t0.clientX, t0.clientY);
    var d = a - drag.a;
    while (d > 180) { d -= 360; }
    while (d < -180) { d += 360; }
    rot += d; drag.a = a; drag.moved += Math.abs(d);
    var now = Date.now(), dt = Math.max(16, now - drag.t) / 1000;
    drag.v = Math.abs(d) / dt; drag.t = now;
    draw();
  }, { passive: true });
  cv.addEventListener("touchend", function () {
    if (!drag) { return; }
    if (drag.moved < 7) { drag = null; paused = false; stopSpin(); }
    else {
      vel = Math.max(700, Math.min(2400, drag.v || 900));
      suppressClick = true;
      drag = null; paused = false;
    }
  });

  /* ---------------- 结果卡 ---------------- */
  function roundText() {
    if (!lastRound) { return { a: "六分之一 · 概率决断", b: "尚未开局", c: "" }; }
    var r = lastRound;
    if (r.win) {
      return {
        a: "连开 " + r.n + " 发 · 收手生还",
        b: "子弹藏在第 " + r.b + " 格",
        c: "再扣一发的命中概率 1/" + (6 - r.n)
      };
    }
    return {
      a: "第 " + r.n + " 发 · 命中",
      b: "子弹藏在第 " + r.b + " 格",
      c: "本发命中概率 1/" + (7 - r.n)
    };
  }
  function drawCardTo(c, g) {
    var W = c.width, H = c.height;
    var gd = g.createLinearGradient(0, 0, 0, H);
    gd.addColorStop(0, "#241f19"); gd.addColorStop(0.55, "#141210"); gd.addColorStop(1, "#0b0908");
    g.fillStyle = gd; g.fillRect(0, 0, W, H);

    g.textAlign = "center";
    g.fillStyle = "#e0c98a";
    g.font = "700 62px -apple-system,'PingFang SC',sans-serif";
    g.fillText("俄罗斯轮盘", W / 2, 132);
    g.fillStyle = "#8a7a5e";
    g.font = "400 28px -apple-system,'PingFang SC',sans-serif";
    g.fillText("六分之一 · 概率决断", W / 2, 184);

    /* 转轮 */
    var oCx = cx, oCy = cy, oR = R, oSt = st;
    cx = W / 2; cy = 700; R = 300;
    var gd2 = g.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.5);
    gd2.addColorStop(0, "rgba(224,201,138,.10)"); gd2.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gd2; g.fillRect(cx - R * 1.5, cy - R * 1.5, R * 3, R * 3);
    if (lastRound) { drawOpen(g, true); }
    else { drawClosed(g, rot, true); }
    cx = oCx; cy = oCy; R = oR; st = oSt;

    var t = roundText();
    g.fillStyle = lastRound ? (lastRound.win ? "#6f8f6a" : "#d97a41") : "#cbb98f";
    g.font = "700 58px -apple-system,'PingFang SC',sans-serif";
    g.fillText(t.a, W / 2, 1085);
    g.fillStyle = "#b8a888";
    g.font = "400 30px -apple-system,'PingFang SC',sans-serif";
    g.fillText(t.b + (t.c ? " · " + t.c : ""), W / 2, 1140);

    g.fillStyle = "rgba(224,201,138,.10)";
    g.fillRect(90, 1190, W - 180, 2);
    g.fillStyle = "#7d7260";
    g.font = "400 26px -apple-system,'PingFang SC',sans-serif";
    g.fillText("总局 " + STATS.g + " · 生还 " + STATS.w + " · 最长连开 " + STATS.best + " 发", W / 2, 1248);
    g.fillStyle = "#5f574a";
    g.font = "400 22px -apple-system,'PingFang SC',sans-serif";
    g.fillText("概率体验与心理博弈 · 无任何现实指引", W / 2, 1300);
  }
  function makeCard(cb) { A.card(1080, 1440, drawCardTo, cb); }

  /* ---------------- 按钮 ---------------- */
  A.tap(btnMain, function () {
    if (st === S_INTRO) { newGame(); }
    else if (st === S_LOAD) { loadAndSpin(); }
    else if (st === S_SPIN) { stopSpin(); }
    else if (st === S_AIM) { fire(); }
    else { newGame(); }
  });
  A.tap(btnRand, function () {
    if (st !== S_LOAD) { A.toast("装弹阶段才能选弹位"); return; }
    cursor = Math.floor(Math.random() * 6); A.buzz(10); updateUI(); draw();
  });
  A.tap(btnQuit, function () {
    if (st !== S_AIM) { return; }
    quit();
  });
  A.tap(Q("btnSave"), function () {
    makeCard(function (u) { A.saveImage(u, "结果图已存入相册"); });
  });
  A.tap(Q("btnPost"), function () {
    makeCard(function (u) {
      var t = roundText();
      A.postNote({
        title: "六分之一轮盘",
        content: "装弹 · 转膛 · 扣扳机。\n" + t.a + "，" + t.b + "。\n" +
          "空枪之后弹膛递进一格，条件概率从 1/6 一路升到 1/1：\n1/6 → 1/5 → 1/4 → 1/3 → 1/2 → 1\n" +
          "什么时候收手，才是这个游戏真正的题面。\n\n#概率 #决断 #心理博弈 #小工具 #六分之一轮盘",
        image: u
      });
    });
  });
  A.tap(Q("btnClear"), function () {
    if (!HIST.length) { A.toast("暂无战绩"); return; }
    A.setJSON("rl_rounds", [], function () { HIST = []; renderHistory(); A.toast("战绩已清空"); });
  });

  /* ---------------- 启动 ---------------- */
  buildProbRow();
  layout();
  updateUI();
  window.addEventListener("resize", layout);
  window.addEventListener("orientationchange", function () { setTimeout(layout, 260); });
  requestAnimationFrame(loop);

  A.getJSON("rl_stats", { g: 0, w: 0, best: 0 }, function (v) {
    STATS = v || { g: 0, w: 0, best: 0 };
    if (!STATS.g) { STATS.g = 0; }
    if (!STATS.w) { STATS.w = 0; }
    if (!STATS.best) { STATS.best = 0; }
    renderStats();
  });
  A.getJSON("rl_rounds", [], function (v) { HIST = v || []; renderHistory(); });

  window.RL = { stat: function () { return st; }, fire: fire, stop: stopSpin, load: loadAndSpin, quit: quit, next: newGame };
})();

})();
