(function(){
  var PFX="m303-";
  function Q(id){ return document.getElementById(PFX+id); }

/* ===== 数据（由构建脚本注入） ===== */
/* ===== 八卦定义 ===== */
/* lines 从下到上：1阳 0阴 */
const TRIGRAMS = {
  '111':{name:'乾',nature:'天',num:1,wuxing:'金',symbol:'☰',lines:[1,1,1]},
  '110':{name:'兑',nature:'泽',num:2,wuxing:'金',symbol:'☱',lines:[1,1,0]},
  '101':{name:'离',nature:'火',num:3,wuxing:'火',symbol:'☲',lines:[1,0,1]},
  '100':{name:'震',nature:'雷',num:4,wuxing:'木',symbol:'☳',lines:[1,0,0]},
  '011':{name:'巽',nature:'风',num:5,wuxing:'木',symbol:'☴',lines:[0,1,1]},
  '010':{name:'坎',nature:'水',num:6,wuxing:'水',symbol:'☵',lines:[0,1,0]},
  '001':{name:'艮',nature:'山',num:7,wuxing:'土',symbol:'☶',lines:[0,0,1]},
  '000':{name:'坤',nature:'地',num:8,wuxing:'土',symbol:'☷',lines:[0,0,0]},
};
const NUM_TO_TRIGRAM = {1:'乾',2:'兑',3:'离',4:'震',5:'巽',6:'坎',7:'艮',8:'坤'};
const WUXING_SHENG = {木:'火',火:'土',土:'金',金:'水',水:'木'};
const WUXING_KE   = {木:'土',土:'水',水:'火',火:'金',金:'木'};
const GAN = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const ZHI = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
const ZHI_NUM = {子:1,丑:2,寅:3,卯:4,辰:5,巳:6,午:7,未:8,申:9,酉:10,戌:11,亥:12};
const SHICHEN = [['子',23],['丑',1],['寅',3],['卯',5],['辰',7],['巳',9],['午',11],['未',13],['申',15],['酉',17],['戌',19],['亥',21]];

/* ===== 工具 ===== */
function $(sel){return document.querySelector(sel)}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function pad2(n){return n<10?'0'+n:''+n}

/* 64卦索引表：由 lines 生成 */
const HEX_BY_LINES = {};
HEX_DATA.forEach(h=>{
  const key = h.lines_top_down.slice().reverse().join(''); /* 转成从下到上 */
  HEX_BY_LINES[key] = h;
});
function findHexByLines(bottomUp){
  return HEX_BY_LINES[bottomUp.join('')] || null;
}

/* 卦画渲染：lines 从下到上，dong 为动爻位（1-6，从下到上） */
function guaLinesHtml(lines, dongSet){
  const topDown = lines.slice().reverse();
  return '<div class="gua-lines">'+topDown.map((v,i)=>{
    const pos = topDown.length - i; /* 从下到上编号 */
    const d = dongSet && dongSet.has(pos);
    return '<div class="yline '+(v?'yang':'yin')+(d?' dong':'')+'"><i></i><i></i></div>';
  }).join('')+'</div>';
}

/* 拆上下卦：lines 从下到上，下卦=1-3爻，上卦=4-6爻 */
function splitTrigrams(linesBottomUp){
  const lower = linesBottomUp.slice(0,3).join('');
  const upper = linesBottomUp.slice(3,6).join('');
  return {lower:TRIGRAMS[lower], upper:TRIGRAMS[upper]};
}

/* ===== 梅花易数引擎 ===== */
/* 除8取卦（余0=8），除6取动爻（余0=6） */
function guaFromNum(n){ const r=n%8; return r===0?8:r; }
function yaoFromNum(n){ const r=n%6; return r===0?6:r; }
function trigramByNum(n){ const nm = NUM_TO_TRIGRAM[n]; return Object.values(TRIGRAMS).find(t=>t.name===nm) || null; }

/* 由上下卦+动爻 构造六爻（从下到上） */
function buildHex(lowerTri, upperTri, dongYao){
  const lines = lowerTri.lines.concat(upperTri.lines);
  const hex = findHexByLines(lines);
  /* 变卦 */
  const newLines = lines.slice();
  newLines[dongYao-1] = newLines[dongYao-1]===1?0:1;
  const bianHex = findHexByLines(newLines);
  /* 互卦：2,3,4爻为下互；3,4,5爻为上互 */
  const huxia = lines.slice(1,4);
  const hushang = lines.slice(2,5);
  const huLower = TRIGRAMS[huxia.join('')];
  const huUpper = TRIGRAMS[hushang.join('')];
  const huLines = huxia.concat(hushang);
  const huHex = findHexByLines(huLines);
  return {lines, hex, bianHex, huLower, huUpper, huHex, dongYao};
}

/* 五行生克判定 */
function shengKe(useWX, tiWX){
  if(useWX===tiWX) return {label:'比和', grade:'吉', cls:'good', desc:'体用五行相同，双方同心同力，事情顺遂，宜主动进取。'};
  if(WUXING_SHENG[useWX]===tiWX) return {label:'用生体', grade:'吉', cls:'good', desc:'用卦五行生体卦，外势来助我，得贵人、外力之助，事情易成，收获大于付出。'};
  if(WUXING_SHENG[tiWX]===useWX) return {label:'体生用', grade:'小凶·泄气', cls:'bad', desc:'体卦生用卦，我耗力去助外，付出多而回报少，事有损耗，需量力而行。'};
  if(WUXING_KE[tiWX]===useWX) return {label:'体克用', grade:'小吉', cls:'good', desc:'体卦克用卦，我有能力制住外势，事情可成但需费心费力，宜主动掌控。'};
  return {label:'用克体', grade:'凶', cls:'bad', desc:'用卦克体卦，外势克制于我，阻力大，事难成，宜守不宜攻，谨慎为上。'};
}

/* 体党用党：互卦与变卦的五行归党 */
/* 归党规则：与体/用五行相同者→同党；生体/用者→帮党（半党）；克体/用者→敌党（对方加分） */
function dangAnalysis(useWX, tiWX, huLower, huUpper, bianLower, bianUpper){
  let tiDang = 0, yongDang = 0;
  const items = [
    {wx:huLower.wuxing, name:huLower.name, tag:'互卦·下'},
    {wx:huUpper.wuxing, name:huUpper.name, tag:'互卦·上'},
  ];
  if(bianLower) items.push({wx:bianLower.wuxing, name:bianLower.name, tag:'变卦·下'});
  if(bianUpper) items.push({wx:bianUpper.wuxing, name:bianUpper.name, tag:'变卦·上'});
  const rows = items.map(it=>{
    const wx = it.wx;
    let toTi = 0, toYong = 0, tiRole = '', yongRole = '';
    if(wx === tiWX){ toTi = 2; tiRole = '同党'; }
    else if(WUXING_SHENG[wx] === tiWX){ toTi = 1; tiRole = '生体'; }
    else if(WUXING_KE[wx] === tiWX){ toTi = -1; tiRole = '克体'; }
    if(wx === useWX){ toYong = 2; yongRole = '同党'; }
    else if(WUXING_SHENG[wx] === useWX){ toYong = 1; yongRole = '生用'; }
    else if(WUXING_KE[wx] === useWX){ toYong = -1; yongRole = '克用'; }
    tiDang += Math.max(0, toTi); yongDang += Math.max(0, toYong);
    return {name:it.name, tag:it.tag, wx, tiRole, yongRole};
  });
  let trend = '';
  if(tiDang > yongDang) trend = '体党势强，对「体」有利，外部助力多于阻力，局势偏主动。';
  else if(yongDang > tiDang) trend = '用党势强，外势较盛，须提防被形势裹挟，宜顺势而谋。';
  else trend = '体用党势相当，胜负取决于当事人能否守正用情、把握时机。';
  return {tiDang, yongDang, rows, trend};
}

/* 时间起卦（梅花易数）：农历年支序+月+日 = 上卦；+时支序 = 下卦；总数 = 动爻 */
function castByTime(lunarYear, lunarMonth, lunarDay, hour){
  const yearZhi = (lunarYear - 4) % 12; /* 0=子 */
  const yz = yearZhi + 1;
  const shichen = hourToShichen(hour);
  const shiNum = ZHI_NUM[shichen];
  const shang = guaFromNum(yz + lunarMonth + lunarDay);
  const xia = guaFromNum(yz + lunarMonth + lunarDay + shiNum);
  const dong = yaoFromNum(yz + lunarMonth + lunarDay + shiNum);
  const lower = trigramByNum(xia);
  const upper = trigramByNum(shang);
  return {lower, upper, dong, shang, xia, yz, lunarYear, lunarMonth, lunarDay, shichen, shiNum};
}
function hourToShichen(hour){
  if(hour >= 23 || hour < 1) return '子';
  return ZHI[Math.floor((hour+1)/2)];
}

/* 数字起卦 */
function castByNumber(n1, n2, n3){
  const shang = guaFromNum(n1);
  const xia = guaFromNum(n2);
  const dong = yaoFromNum(n3 || (n1+n2));
  return {lower:trigramByNum(xia), upper:trigramByNum(shang), dong, shang, xia};
}

/* 随机起卦：三枚铜钱六次，或直接随机 */
function castRandom(){
  /* 每次 3 枚铜钱：字=2 花=3，4=老阴(动) 5=少阳 6=少阴 7=老阳(动) */
  const lines=[], dongs=[];
  for(let i=0;i<6;i++){
    let sum=0;
    for(let j=0;j<3;j++) sum += Math.random()<0.5?2:3;
    let v;
    if(sum===6){v=0;dongs.push(i+1);}
    else if(sum===7){v=1;}
    else if(sum===8){v=0;}
    else {v=1;dongs.push(i+1);}
    lines.push(v);
  }
  const lower = TRIGRAMS[lines.slice(0,3).join('')];
  const upper = TRIGRAMS[lines.slice(3,6).join('')];
  const dong = dongs.length?dongs[0]:Math.floor(Math.random()*6)+1;
  return {lower, upper, dong, lines, dongs, random:true};
}

/* ===== 农历转换（双表查表法，1887-2100） ===== */
const LUNAR_MONTH_DAYS = [1887,5780,5802,19157,2742,50359,1198,2646,46378,7466,3412,30122,5482,67949,2396,5294,43597,6732,6954,36181,2772,4954,18781,2396,54427,5274,6730,47781,5800,6868,21210,4790,59703,2350,5270,46667,3402,3496,38325,1388,4782,18735,2350,52374,6804,7498,44457,2906,1388,29294,4700,63789,6442,6804,56138,5802,2772,38235,1210,4698,22827,5418,63125,3476,5802,43701,2484,5302,27223,2646,70954,7466,3412,54698,5482,2412,38062,5294,2636,32038,6954,60245,2772,4826,43357,2394,5274,39501,6730,72357,5800,5844,53978,4790,2358,38039,5270,87627,3402,3496,54708,5484,4782,43311,2350,3222,27978,7498,68965,2904,5484,45677,4700,6444,39573,6804,6986,19285,2772,62811,1210,4698,47403,5418,5780,38570,5546,76469,2420,5302,51799,2646,5414,36501,3412,5546,18869,2412,54446,5276,6732,48422,6822,2900,28010,4826,92509,2394,5274,55883,6730,6820,47956,5812,2778,18779,2358,62615,5270,5450,46757,3492,5556,27318,4718,67887,2350,3222,52554,7498,3428,38252,5468,4700,31022,6444,64149,6804,6986,43861,2772,5338,35421,2650,70955,5418,5780,54954,5546,2740,38074,5302,2646,29991,3366,61011,3412,5546,43445,2412,5294,35406,6732,72998,6820,6996,52586,2778,2396,38045,5274,6698,23333,6820,64338,5812,2746,43355,2358,5270,39499,5450,79525,3492,5548];
const LUNAR_SOLAR_11 = [1887,966732,967231,967733,968265,968766,969297,969798,970298,970829,971330,971830,972362,972863,973395,973896,974397,974928,975428,975929,976461,976962,977462,977994,978494,979026,979526,980026,980558,981059,981559,982091,982593,983124,983624,984124,984656,985157,985656,986189,986690,987191,987722,988222,988753,989254,989754,990286,990788,991288,991819,992319,992851,993352,993851,994383,994885,995385,995917,996418,996918,997450,997949,998481,998982,999483,1000014,1000515,1001016,1001548,1002047,1002578,1003080,1003580,1004111,1004613,1005113,1005645,1006146,1006645,1007177,1007678,1008209,1008710,1009211,1009743,1010243,1010743,1011275,1011775,1012306,1012807,1013308,1013840,1014341,1014841,1015373,1015874,1016404,1016905,1017405,1017937,1018438,1018939,1019471,1019972,1020471,1021002,1021503,1022035,1022535,1023036,1023568,1024069,1024568,1025100,1025601,1026102,1026633,1027133,1027666,1028167,1028666,1029198,1029699,1030199,1030730,1031231,1031763,1032264,1032764,1033296,1033797,1034297,1034828,1035329,1035830,1036362,1036861,1037393,1037894,1038394,1038925,1039427,1039927,1040459,1040959,1041491,1041992,1042492,1043023,1043524,1044024,1044556,1045057,1045558,1046090,1046590,1047121,1047622,1048122,1048654,1049154,1049655,1050187,1050689,1051219,1051720,1052220,1052751,1053252,1053752,1054284,1054786,1055285,1055817,1056317,1056849,1057349,1057850,1058382,1058883,1059383,1059915,1060415,1060947,1061447,1061947,1062479,1062981,1063480,1064012,1064514,1065014,1065545,1066045,1066577,1067078,1067578,1068110,1068611,1069112,1069642,1070142,1070674,1071175,1071675,1072207,1072709,1073209,1073740,1074241,1074741,1075273,1075773,1076305,1076807,1077308,1077839,1078340,1078840,1079372,1079871,1080403,1080904];
function lunarGetBit(data, length, shift){ return (data & (((1 << length) - 1) << shift)) >> shift; }
function solarToInt(y, m, d){
  m = (m + 9) % 12;
  y = parseInt(y) - parseInt(m / 10);
  return 365 * y + parseInt(y / 4) - parseInt(y / 100) + parseInt(y / 400) + parseInt((m * 306 + 5) / 10) + (d - 1);
}
function solar2lunar(y, m, d){
  if(!LUNAR_MONTH_DAYS.length) return null;
  let index = y - LUNAR_SOLAR_11[0];
  const data = (y << 9) | (m << 5) | d;
  if(LUNAR_SOLAR_11[index] > data) index--;
  if(index < 0 || index >= LUNAR_MONTH_DAYS.length - 1) return null;
  const solar11 = LUNAR_SOLAR_11[index];
  const y11 = lunarGetBit(solar11, 12, 9);
  const m11 = lunarGetBit(solar11, 4, 5);
  const d11 = lunarGetBit(solar11, 5, 0);
  let offset = solarToInt(y, m, d) - solarToInt(y11, m11, d11);
  const days = LUNAR_MONTH_DAYS[index];
  const leap = lunarGetBit(days, 4, 13);
  const lunarYear = index + LUNAR_SOLAR_11[0];
  let lunarMonth = 1;
  offset += 1;
  for(let i=0; i<13; i++){
    const dm = lunarGetBit(days, 1, 12-i) === 1 ? 30 : 29;
    if(offset > dm){ lunarMonth++; offset -= dm; }
    else break;
  }
  let isLeap = false;
  if(leap !== 0 && lunarMonth > leap){
    lunarMonth = lunarMonth - 1;
    if(lunarMonth === leap) isLeap = true;
  }
  return {year:lunarYear, month:lunarMonth, day:offset, isLeap};
}
function ganZhiYear(y){
  return GAN[(y-4)%10] + ZHI[(y-4)%12];
}
const LUNAR_MONTH_CN = ['','正月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','腊月'];

/* ===== 渲染 ===== */
let state = {view:'pan', filter:{sec:'all', tri:'all'}, hexIdx:0};

const VIEWS = {pan:renderPan, cast:renderCast, about:renderAbout};

function render(){
  const view = location.hash.replace('#/','') || 'pan';
  const vname = VIEWS[view] ? view : 'pan';
  state.view = vname;
  document.querySelectorAll('.m303 nav.tabs button').forEach(b=>{
    b.classList.toggle('active', b.dataset.view===vname);
  });
  VIEWS[vname]();
}

/* tab 点击绑定 */
function bindTabs(){
  document.querySelectorAll('.m303 nav.tabs button').forEach(b=>{
    if(b._bound) return;
    b._bound = true;
    b.addEventListener('click', ()=>{
      location.hash = '#/' + b.dataset.view;
    });
  });
}

/* 卦盘 */
function renderPan(){
  const el = Q('view');
  let list = HEX_DATA.slice();
  if(state.filter.sec!=='all') list = list.filter(h=>h.section===state.filter.sec);
  if(state.filter.tri!=='all'){
    const tg = TRIGRAMS[state.filter.tri];
    list = list.filter(h=>h.eyebrow.includes(tg.name));
  }
  const cells = list.map(h=>{
    const bottomUp = h.lines_top_down.slice().reverse();
    return '<div class="hex-cell" data-idx="'+h.index+'">'+
      '<div class="no">'+pad2(h.index)+'</div>'+
      guaLinesHtml(bottomUp)+
      '<div class="nm">'+esc(h.title)+'</div></div>';
  }).join('');
  el.innerHTML =
    '<div class="card">'+
      '<h2>六十四卦卦盘</h2>'+
      '<div class="hint">点击任一卦进入详解：卦辞、彖、大象、六爻原文与白话、小象、象数分析。共 '+HEX_DATA.length+' 卦。</div>'+
      '<div class="filters">'+
        '<div class="fgroup"><label>经部</label>'+
          '<button class="fbtn '+(state.filter.sec==='all'?'active':'')+'" data-sec="all">全部</button>'+
          '<button class="fbtn '+(state.filter.sec==='上经'?'active':'')+'" data-sec="上经">上经 1-30</button>'+
          '<button class="fbtn '+(state.filter.sec==='下经'?'active':'')+'" data-sec="下经">下经 31-64</button>'+
        '</div>'+
        '<div class="fgroup"><label>八卦</label>'+
          '<button class="fbtn '+(state.filter.tri==='all'?'active':'')+'" data-tri="all">全部</button>'+
          ['111','110','101','100','011','010','001','000'].map(k=>{
            const t=TRIGRAMS[k];
            return '<button class="fbtn '+(state.filter.tri===k?'active':'')+'" data-tri="'+k+'">'+t.symbol+' '+t.name+'</button>';
          }).join('')+
        '</div>'+
      '</div>'+
      '<input class="searchbox" id="m303-hexsearch" placeholder="搜索卦名，如：乾、既济、未济…">'+
      '<div class="divider"></div>'+
      '<div class="hex-grid" id="m303-hexgrid">'+cells+'</div>'+
    '</div>';
  /* 事件 */
  el.querySelectorAll('.hex-cell').forEach(c=>{
    c.addEventListener('click', ()=>location.hash='#/gua/'+c.dataset.idx);
  });
  el.querySelectorAll('.fbtn[data-sec]').forEach(b=>{
    b.addEventListener('click', ()=>{state.filter.sec=b.dataset.sec; renderPan();});
  });
  el.querySelectorAll('.fbtn[data-tri]').forEach(b=>{
    b.addEventListener('click', ()=>{state.filter.tri=b.dataset.tri; renderPan();});
  });
  Q('hexsearch').addEventListener('input', e=>{
    const q = e.target.value.trim();
    const grid = Q('hexgrid');
    grid.querySelectorAll('.hex-cell').forEach(c=>{
      const nm = c.querySelector('.nm').textContent;
      const no = c.querySelector('.no').textContent;
      c.style.display = (!q || nm.includes(q) || no===q || no===('0'+q)) ? '' : 'none';
    });
  });
}

/* 卦详情 */
function renderGua(idx){
  const h = HEX_DATA.find(x=>x.index===idx);
  if(!h){ location.hash='#/'; return; }
  const bottomUp = h.lines_top_down.slice().reverse();
  const tg = splitTrigrams(bottomUp);
  const yaoItems = h.yaos.map((y,i)=>{
    const isYang = y.label.includes('九');
    const pos = i+1;
    const dongSet = new Set([pos]);
    return '<li class="yao-item" data-y="'+pos+'">'+
      '<div class="yao-top">'+
        '<span class="yao-label">'+esc(y.label)+'</span>'+
        '<span class="yao-type">'+esc(y.type)+'</span>'+
        '<span class="tag '+(isYang?'gold':'jade')+'">'+(isYang?'阳':'阴')+'</span>'+
        '<span style="margin-left:auto;color:var(--ink3);font-size:11px">爻位 '+pos+'</span>'+
      '</div>'+
      '<div class="yao-text">'+esc(y.text)+'</div>'+
      '<div class="yao-baihua">'+esc(y.baihua)+'</div>'+
      (y.xiaoxiang?'<div class="yao-xx">'+esc(y.xiaoxiang)+'</div>':'')+
    '</li>';
  }).join('');

  const scripturesHtml = h.scriptures.map(s=>{
    return '<div>'+
      '<h3>'+esc(s.name)+'</h3>'+
      '<blockquote>'+esc(s.text)+'</blockquote>'+
      '<div class="baihua">'+esc(s.baihua)+'</div>'+
    '</div>';
  }).join('');

  const specialHtml = (h.special&&h.special.length)?
    '<details><summary>特例爻（'+(h.index===1?'用九':'用六')+'）</summary>'+
      h.special.map(s=>'<blockquote>'+esc(s.text)+'</blockquote><div class="baihua">'+esc(s.xiaoxiang)+'</div>').join('')+
    '</details>':'';
  const wenyanHtml = (h.wenyan&&h.wenyan.length)?
    '<details><summary>《文言》专论（'+h.wenyan.length+' 段）</summary>'+
      h.wenyan.map(w=>'<div style="margin-bottom:12px"><b style="color:var(--cinnabar2)">'+esc(w.title)+'</b><blockquote>'+esc(w.text)+'</blockquote></div>').join('')+
    '</details>':'';

  const changesHtml = (h.changes&&h.changes.length)?
    '<details><summary>单爻发动变卦（'+h.changes.length+' 种）</summary><div class="change-list">'+
      h.changes.map(c=>{
        const m = c.match(/^(.*?) → (.*?) · 第(\d+)卦/);
        if(!m) return '<div class="chg">'+esc(c)+'</div>';
        return '<div class="chg"><span>'+esc(m[1])+'</span><span>→</span><b>'+esc(m[2])+'</b><span class="tag jade">第'+m[3]+'卦</span></div>';
      }).join('')+
    '</div></details>':'';

  const prev = HEX_DATA.find(x=>x.index===idx-1);
  const next = HEX_DATA.find(x=>x.index===idx+1);

  elHtml =
    '<div class="card">'+
      '<div class="hex-head">'+
        '<div class="symbol">'+esc(h.symbol)+'</div>'+
        '<div class="titles">'+
          '<h2>'+esc(h.title)+'</h2>'+
          '<div class="sub">'+esc(h.eyebrow)+'</div>'+
          '<div class="hex-meta">'+
            '<span class="tag gold">'+esc(tg.lower.name)+'下'+esc(tg.upper.name)+'上</span>'+
            '<span class="tag">'+esc(tg.lower.nature)+'·'+esc(tg.upper.nature)+'</span>'+
            '<span class="tag red">第 '+h.index+' 卦 · '+esc(h.section)+'</span>'+
          '</div>'+
        '</div>'+
        guaLinesHtml(bottomUp)+
      '</div>'+
      '<div class="hex-meta" style="margin-top:14px">'+
        '<span>下卦五行：'+esc(tg.lower.wuxing)+'</span>'+
        '<span>上卦五行：'+esc(tg.upper.wuxing)+'</span>'+
        '<span>互卦：'+(h.互卦||'—')+'</span>'+
        '<span>错卦：'+(h.错卦||'—')+'</span>'+
        '<span>综卦：'+(h.综卦||'—')+'</span>'+
      '</div>'+
      '<div class="divider"></div>'+
      '<h3>卦辞</h3><blockquote>'+esc(h.guaci)+'</blockquote>'+
      '<div class="baihua">'+esc(h.guaci_baihua)+'</div>'+
      '<div class="divider"></div>'+
      '<h3>彖 · 象</h3>'+scripturesHtml+
      '<div class="divider"></div>'+
      '<h3>六爻详解 <span class="small-note">（点击爻条可高亮）</span></h3>'+
      '<ul class="yao-list">'+yaoItems+'</ul>'+
      specialHtml+wenyanHtml+
      '<div class="divider"></div>'+
      '<h3>象数分析</h3>'+
      '<div class="analysis-grid">'+
        '<div class="item"><div class="k">互卦</div><div class="v">'+esc(h.互卦||'—')+'</div></div>'+
        '<div class="item"><div class="k">错卦</div><div class="v">'+esc(h.错卦||'—')+'</div></div>'+
        '<div class="item"><div class="k">综卦</div><div class="v">'+esc(h.综卦||'—')+'</div></div>'+
        '<div class="item"><div class="k">应位</div><div class="v">'+esc(h.应位||'—')+'</div></div>'+
        '<div class="item"><div class="k">中正</div><div class="v">'+esc(h.中正||'—')+'</div></div>'+
      '</div>'+
      changesHtml+
      '<div class="divider"></div>'+
      '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">'+
        (prev?'<button class="btn ghost" data-nav="'+(idx-1)+'">← 前卦 · '+esc(prev.title)+'</button>':'<span></span>')+
        (next?'<button class="btn ghost" data-nav="'+(idx+1)+'">后卦 · '+esc(next.title)+' →</button>':'<span></span>')+
      '</div>'+
    '</div>';
  Q('view').innerHTML = elHtml;
  Q('view').querySelectorAll('.yao-item').forEach(it=>{
    it.addEventListener('click', ()=>{
      it.classList.toggle('open');
    });
  });
  Q('view').querySelectorAll('[data-nav]').forEach(b=>{
    b.addEventListener('click', ()=>location.hash='#/gua/'+b.dataset.nav);
  });
}

/* 起卦 */
function renderCast(){
  Q('view').innerHTML =
    '<div class="card">'+
      '<h2>梅花易数 · 起卦</h2>'+
      '<div class="hint">三种起卦法 → 本卦 / 互卦 / 变卦 / 体用生克 / 体党用党。梅花起卦取数：先天八卦数 乾1 兑2 离3 震4 巽5 坎6 艮7 坤8。</div>'+
      '<div class="cast-methods">'+
        '<div class="cast-card">'+
          '<h3>时间起卦</h3>'+
          '<p>农历年（地支序）+月+日 得上卦；再+时辰序 得下卦与动爻。</p>'+
          '<input id="m303-c-solar" placeholder="公历日期，如 2026-09-11">'+
          '<input id="m303-c-hour" type="number" min="0" max="23" placeholder="时辰（0-23时）">'+
          '<button class="btn" id="m303-btn-time">以此刻起卦</button>'+
        '</div>'+
        '<div class="cast-card">'+
          '<h3>数字起卦</h3>'+
          '<p>第一个数除8得外卦（上），第二个数除8得内卦（下），第三个数（或两数之和）除6得动爻。</p>'+
          '<input id="m303-c-n1" type="number" placeholder="第一个数">'+
          '<input id="m303-c-n2" type="number" placeholder="第二个数">'+
          '<input id="m303-c-n3" type="number" placeholder="第三个数（可选）">'+
          '<button class="btn" id="m303-btn-num">起卦</button>'+
        '</div>'+
        '<div class="cast-card">'+
          '<h3>铜钱摇卦</h3>'+
          '<p>模拟三枚铜钱掷六次：字字字=老阴(动)、花花花=老阳(动)、其余为少阴少阳。有动爻取第一动爻。</p>'+
          '<button class="btn" id="m303-btn-random">摇一卦</button>'+
        '</div>'+
      '</div>'+
      '<div id="m303-cast-result"></div>'+
    '</div>';
  const fillNow = ()=>{
    const now = new Date();
    const lm = solar2lunar(now.getFullYear(), now.getMonth()+1, now.getDate());
    Q('c-solar').value = now.getFullYear()+'-'+pad2(now.getMonth()+1)+'-'+pad2(now.getDate());
    Q('c-hour').value = now.getHours();
  };
  fillNow();
  Q('btn-time').addEventListener('click', ()=>{
    const s = Q('c-solar').value.trim();
    const hh = parseInt(Q('c-hour').value,10);
    if(!s){toast('请填写公历日期');return;}
    const m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if(!m){toast('日期格式：YYYY-MM-DD');return;}
    const lm = solar2lunar(+m[1], +m[2], +m[3]);
    if(!lm){toast('农历转换失败，日期超出支持范围');return;}
    const r = castByTime(lm.year, lm.month, lm.day, isNaN(hh)?12:hh);
    const lunarDesc = ganZhiYear(lm.year)+'年（'+lm.year+'年）'+LUNAR_MONTH_CN[lm.month]+(lm.isLeap?'（闰）':'')+lm.day+'日 · '+r.shichen+'时';
    showCastResult(r, {method:'时间起卦', desc:lunarDesc});
  });
  Q('btn-num').addEventListener('click', ()=>{
    const n1 = parseInt(Q('c-n1').value,10);
    const n2 = parseInt(Q('c-n2').value,10);
    const n3 = parseInt(Q('c-n3').value,10);
    if(isNaN(n1)||isNaN(n2)){toast('请填写前两个数');return;}
    const r = castByNumber(n1, n2, isNaN(n3)?null:n3);
    showCastResult(r, {method:'数字起卦', desc:n1+' / '+n2+(isNaN(n3)?'':' / '+n3)});
  });
  Q('btn-random').addEventListener('click', ()=>{
    const r = castRandom();
    const desc = r.dongs && r.dongs.length ? ('动爻：'+r.dongs.map(i=>'第'+i+'爻').join('、')) : '六爻安静（重摇或取随机动爻）';
    showCastResult(r, {method:'铜钱摇卦', desc});
  });
}

function showCastResult(r, info){
  const b = buildHex(r.lower, r.upper, r.dong);
  if(!b.hex){toast('起卦失败，请重试');return;}
  /* 体用：无动爻之卦为体，有动爻之卦为用。动爻在下卦→下卦为用上卦为体；在上卦→上卦为用下卦为体 */
  const dongInLower = r.dong <= 3;
  const ti = dongInLower ? r.upper : r.lower;
  const yong = dongInLower ? r.lower : r.upper;
  const sk = shengKe(yong.wuxing, ti.wuxing);

  /* 动爻爻辞 */
  const dongYao = b.hex.yaos[r.dong-1];
  /* 互卦五行 */
  const huWX = [b.huLower.wuxing, b.huUpper.wuxing];
  /* 变卦上下卦 */
  const bianTri = b.bianHex ? splitTrigrams(b.bianHex.lines_top_down.slice().reverse()) : null;
  const bianWX = bianTri ? bianTri.lower.wuxing : null;
  /* 体党用党 */
  const dang = dangAnalysis(yong.wuxing, ti.wuxing, b.huLower, b.huUpper, bianTri?bianTri.lower:null, bianTri?bianTri.upper:null);
  const dangRows = dang.rows.map(r=>
    '<tr><td>'+esc(r.tag)+'</td><td>'+esc(r.name)+'（'+esc(r.wx)+'）</td>'+
    '<td class="'+(r.tiRole.includes('克')?'bad':(r.tiRole?'good':''))+'">'+(r.tiRole||'—')+'</td>'+
    '<td class="'+(r.yongRole.includes('克')?'bad':(r.yongRole?'good':''))+'">'+(r.yongRole||'—')+'</td></tr>'
  ).join('');

  Q('cast-result').innerHTML =
    '<div class="divider"></div>'+
    '<div class="note-box">起卦法：'+esc(info.method)+'（'+esc(info.desc)+'）· 动爻：第'+r.dong+'爻</div>'+
    '<div class="card">'+
      '<h3>本卦 · '+esc(b.hex.title)+' <span class="tag red">第'+b.hex.index+'卦</span></h3>'+
      '<div class="result-hex">'+
        '<div class="sym">'+esc(b.hex.symbol)+'</div>'+
        guaLinesHtml(b.lines, new Set([r.dong]))+
        '<div class="meta"><h4>'+esc(b.hex.title)+'</h4>'+
        '<div class="sub">'+esc(r.upper.name)+'上 '+esc(r.lower.name)+'下 · '+esc(r.upper.nature)+esc(r.lower.nature)+' · 外'+esc(r.upper.wuxing)+' 内'+esc(r.lower.wuxing)+'</div></div>'+
      '</div>'+
      '<blockquote>'+esc(b.hex.guaci)+'</blockquote>'+
      '<div class="baihua">'+esc(b.hex.guaci_baihua)+'</div>'+
      '<div class="ti-yong">'+
        '<div class="pill"><b>体 · '+esc(ti.name)+'</b><span>'+esc(ti.wuxing)+' · 无动爻</span></div>'+
        '<div class="pill yong"><b>用 · '+esc(yong.name)+'</b><span>'+esc(yong.wuxing)+' · 有动爻</span></div>'+
      '</div>'+
      '<div class="verdict">'+
        '<div class="v-title">体用关系 · '+esc(sk.label)+'（'+esc(sk.grade)+'）</div>'+
        '<div style="font-size:13.5px">'+esc(sk.desc)+'</div>'+
      '</div>'+
      '<table class="shengke-table">'+
        '<tr><th>分析项</th><th>内容</th><th>判断</th></tr>'+
        '<tr><td>体卦</td><td>'+esc(ti.name)+'（'+esc(ti.nature)+'，'+esc(ti.wuxing)+'）</td><td>自身 / 所问之事主体</td></tr>'+
        '<tr><td>用卦</td><td>'+esc(yong.name)+'（'+esc(yong.nature)+'，'+esc(yong.wuxing)+'）</td><td>外势 / 所问之事客体</td></tr>'+
        '<tr><td>互卦</td><td>'+esc(b.huLower.name)+'（'+esc(huWX[0])+'）· '+esc(b.huUpper.name)+'（'+esc(huWX[1])+'）</td><td>过程中的中间态势</td></tr>'+
        (b.bianHex?'<tr><td>变卦</td><td>'+esc(b.bianHex.title)+'（'+esc(bianWX)+'）· 第'+b.bianHex.index+'卦</td><td>事态发展趋势</td></tr>':'')+
      '</table>'+
      '<h3 style="margin-top:16px">体党 · 用党</h3>'+
      '<div class="hint">互卦、变卦各卦五行，看其生克归属：同党（+2）、生体/生用（+1）、克体/克用（外势压内）。</div>'+
      '<table class="shengke-table">'+
        '<tr><th>来源</th><th>卦 · 五行</th><th>对体</th><th>对用</th></tr>'+
        dangRows+
      '</table>'+
      '<div style="font-size:13px;color:var(--ink2);margin-top:8px">体党 '+dang.tiDang+' 势 · 用党 '+dang.yongDang+' 势 —— '+esc(dang.trend)+'</div>'+
    '</div>'+
    '<div class="card">'+
      '<h3>动爻解读 · '+esc(dongYao.label)+'</h3>'+
      '<blockquote>'+esc(dongYao.text)+'</blockquote>'+
      '<div class="baihua">'+esc(dongYao.baihua)+'</div>'+
      (dongYao.xiaoxiang?'<div class="yao-xx">'+esc(dongYao.xiaoxiang)+'</div>':'')+
    '</div>'+
    (b.bianHex?'<div class="card">'+
      '<h3>变卦 · '+esc(b.bianHex.title)+' <span class="tag jade">趋势</span></h3>'+
      '<div class="result-hex">'+
        '<div class="sym">'+esc(b.bianHex.symbol)+'</div>'+
        '<div class="meta"><h4>'+esc(b.bianHex.title)+'</h4><div class="sub">动爻变后所成之卦，预示事态走向</div></div>'+
      '</div>'+
      '<blockquote>'+esc(b.bianHex.guaci)+'</blockquote>'+
      '<div class="baihua">'+esc(b.bianHex.guaci_baihua)+'</div>'+
    '</div>':'')+
    '<div class="note-box">体用生克为传统梅花断卦框架，吉凶需结合所问之事具体判断，不宜机械套用。</div>';
  Q('cast-result').scrollIntoView({behavior:'smooth'});
}

/* 说明 */
function renderAbout(){
  Q('view').innerHTML =
    '<div class="card">'+
      '<h2>关于本集</h2>'+
      '<p style="font-size:14px;color:var(--ink2);line-height:2">'+
      '本页为「玄学口袋 · 易经深度集」基础层：六十四卦全文（卦辞、彖、大象、六爻爻辞）+ 白话详解 + 小象 + 象数分析（互卦、错卦、综卦、应位、中正、单爻变卦），乾坤两卦另附《文言》专论与用九用六。'+
      '</p>'+
      '<div class="divider"></div>'+
      '<h3>梅花易数引擎</h3>'+
      '<p style="font-size:13.5px;color:var(--ink2);line-height:2">'+
      '支持时间起卦（公历自动转农历）、数字起卦、铜钱摇卦三种方式；自动排出本卦、互卦（二三四爻为下互、三四五爻为上互）、变卦；'+
      '以无动爻之卦为体、有动爻之卦为用，判体用五行生克，并结合互卦变卦五行归党（体党/用党）提示势力消长。'+
      '</p>'+
      '<div class="divider"></div>'+
      '<h3>数据与免责</h3>'+
      '<p style="font-size:13px;color:var(--ink3);line-height:2">'+
      '经文与白话整理参考公开通行本《周易》（卦辞据原典，白话为解释性转述，古籍存在异文与断句差异，严肃校勘请对照具体底本）；'+
      '农历转换采用经典查表法（1900-2100）。占筮结论仅供参考，不作决策依据。'+
      '</p>'+
    '</div>';
}

/* toast */
function toast(msg){
  let t = Q('toast');
  if(!t){
    t = document.createElement('div');
    t.id='m303-toast';
    t.style.cssText='position:fixed;bottom:26px;left:50%;transform:translateX(-50%);background:var(--cinnabar);color:#f7ead0;padding:10px 22px;border-radius:8px;font-size:13px;z-index:99;box-shadow:var(--shadow);transition:opacity .3s';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity=1;
  clearTimeout(t._h);
  t._h = setTimeout(()=>t.style.opacity=0, 2200);
}

/* 路由 */
function router(){
  bindTabs();
  const m = location.hash.match(/^#\/gua\/(\d+)/);
  if(m){ renderGua(+m[1]); return; }
  render();
}
window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);


/* ================= 玄学口袋 · 平台能力增强（历史/收藏/签卡） ================= */
var XX = (function(){
  "use strict";
  var FAV_KEY = "xx_favs", HIS_KEY = "xx_history", CAST_KEY = "xx_casts";
  var favs = {};

  function hexByIdx(i){ for(var k=0;k<HEX_DATA.length;k++) if(HEX_DATA[k].index===i) return HEX_DATA[k]; return null; }

  AAPT.getJSON(FAV_KEY, {}, function(o){ favs=o||{}; });
  function isFav(i){ return !!favs["g"+i]; }
  function toggleFav(i){
    var k="g"+i;
    if(favs[k]) delete favs[k]; else favs[k]=Date.now();
    AAPT.setJSON(FAV_KEY, favs, function(){
      AAPT.toast(isFav(i)?"已收藏本卦":"已取消收藏");
      injectDetailBar(i);
    });
  }

  /* ---------- 签卡（纯矢量） ---------- */
  function guaDraw(x, h, dong, cx, top, w){
    var bU = h.lines_top_down.slice().reverse(); /* 自下而上 */
    var lh=Math.round(w/3.8), bh=Math.round(lh*0.40);
    for(var i=0;i<6;i++){
      var yang = bU[i]===1, y=top+(5-i)*lh, hl=(i+1===dong);
      x.fillStyle = hl ? "#d4a853" : "#f0e6d2";
      if(yang){ x.fillRect(cx-w/2,y,w,bh); }
      else{ var seg=Math.round(w*0.40),gap=Math.round(w*0.20);
        x.fillRect(cx-w/2,y,seg,bh); x.fillRect(cx+w/2-seg,y,seg,bh); }
    }
  }
  function wrap(x,text,cx,y,maxW,lh,maxLines){
    var line="",lines=[];
    for(var i=0;i<text.length;i++){ var ch=text[i];
      if(line&&x.measureText(line+ch).width>maxW){lines.push(line);line=ch;} else line+=ch;
      if(lines.length>=maxLines)break; }
    if(line&&lines.length<maxLines)lines.push(line);
    lines.forEach(function(l,i){x.fillText(l,cx,y+i*lh);});
    return y+lines.length*lh;
  }
  function drawCard(h, dong, yaoText, baihua, tagLine){
    var c=document.createElement("canvas"); c.width=1080; c.height=1440;
    var x=c.getContext("2d");
    var g=x.createLinearGradient(0,0,0,1440);
    g.addColorStop(0,"#241a12"); g.addColorStop(0.55,"#1E1610"); g.addColorStop(1,"#15100b");
    x.fillStyle=g; x.fillRect(0,0,1080,1440);
    /* 描金双框 */
    x.strokeStyle="rgba(212,168,83,.55)"; x.lineWidth=3; x.strokeRect(30,30,1020,1380);
    x.strokeStyle="rgba(212,168,83,.25)"; x.lineWidth=1.5; x.strokeRect(46,46,988,1348);
    x.textAlign="center";
    x.fillStyle="#D4A853"; x.font='26px "Songti SC","STSong",serif';
    x.fillText("玄 学 口 袋 · 易 经", 540, 118);
    x.fillStyle="#A08E72"; x.font='20px serif';
    x.fillText(tagLine||"", 540, 160);
    guaDraw(x, h, dong, 540, 208, 280);
    x.fillStyle="#E8DCC8"; x.font='900 86px "Songti SC","STSong",serif';
    x.fillText("第"+h.index+"卦 · "+h.title, 540, 742);
    x.fillStyle="#C0563E"; x.font='30px "Songti SC",serif';
    x.fillText(h.eyebrow, 540, 800);
    x.fillStyle="#f0e6d2"; x.font='34px "Songti SC",serif';
    var y=wrap(x, yaoText||h.guaci, 540, 872, 880, 50, 3);
    x.fillStyle="#A08E72"; x.font='27px "Songti SC",serif';
    y=wrap(x, baihua||h.guaci_baihua, 540, y+26, 880, 42, 4);
    x.strokeStyle="rgba(212,168,83,.4)"; x.beginPath(); x.moveTo(330,1286); x.lineTo(750,1286); x.stroke();
    x.fillStyle="#A08E72"; x.font='21px "Songti SC",serif';
    x.fillText("AI PASSPORT · 玄学口袋 · 传统文化参考", 540, 1334);
    x.fillText("在▁▁搜索「玄学口袋」同款小工具", 540, 1372);
    return c.toDataURL("image/png");
  }

  /* ---------- 详情页动作条 ---------- */
  function injectDetailBar(idx){
    var view=Q("view"); if(!view) return;
    var old=Q("xx-bar"); if(old) old.parentNode.removeChild(old);
    var card=view.querySelector(".card")||view;
    var bar=document.createElement("div");
    bar.id="m303-xx-bar";
    bar.style.cssText="display:flex;margin:14px 0 4px;";
    bar.innerHTML=
      '<button type="button" data-x="fav" style="flex:1;margin-right:8px;padding:11px 0;border-radius:10px;border:1px solid rgba(212,168,83,.5);background:rgba(212,168,83,.08);color:#e7c884;font-size:13.5px">'+(isFav(idx)?"★ 已收藏":"☆ 收 藏")+'</button>'+
      '<button type="button" data-x="save" style="flex:1;margin:0 8px;padding:11px 0;border-radius:10px;border:1px solid rgba(212,168,83,.5);background:rgba(212,168,83,.08);color:#e7c884;font-size:13.5px">存 签 卡</button>'+
      '<button type="button" data-x="post" style="flex:1;margin-left:8px;padding:11px 0;border-radius:10px;border:1px solid rgba(212,168,83,.5);background:rgba(212,168,83,.08);color:#e7c884;font-size:13.5px">发笔记</button>';
    card.appendChild(bar);
  }
  function onDetail(idx){
    var h=hexByIdx(idx); if(!h) return;
    AAPT.pushHistory(HIS_KEY, {t:"第"+h.index+"卦 · "+h.title, i:idx, ts:Date.now()}, 30, function(){});
    injectDetailBar(idx);
  }

  /* ---------- 起卦结果动作条 ---------- */
  var lastCast=null;
  function onCast(r, info){
    lastCast={r:r, info:info};
    var b=buildHex(r.lower,r.upper,r.dong);
    if(!b.hex)return;
    var box=Q("cast-result"); if(!box)return;
    var old=Q("xx-bar"); if(old)old.parentNode.removeChild(old);
    var bar=document.createElement("div");
    bar.id="m303-xx-bar"; bar.style.cssText="display:flex;margin-top:14px;";
    bar.innerHTML=
      '<button type="button" data-x="csave" style="flex:1;margin-right:8px;padding:11px 0;border-radius:10px;border:1px solid rgba(212,168,83,.5);background:rgba(212,168,83,.08);color:#e7c884;font-size:13.5px">存 签 卡</button>'+
      '<button type="button" data-x="cpost" style="flex:1;margin-left:8px;padding:11px 0;border-radius:10px;border:1px solid rgba(212,168,83,.5);background:rgba(212,168,83,.08);color:#e7c884;font-size:13.5px">发笔记</button>';
    box.appendChild(bar);
    AAPT.pushHistory(CAST_KEY, {t:b.hex.title+(r.dong?(" · 动爻"+r.dong):" · 静卦"), i:b.hex.index, d:r.dong||0, ts:Date.now()}, 30, function(){});
  }

  function castCard(){
    if(!lastCast)return null;
    var b=buildHex(lastCast.r.lower,lastCast.r.upper,lastCast.r.dong);
    var h=b.hex; if(!h)return null;
    var dy=lastCast.r.dong?h.yaos[lastCast.r.dong-1]:null;
    var tag=(lastCast.info&&lastCast.info.tag)||"梅花易数 · 体用生克";
    return drawCard(h, lastCast.r.dong, dy?dy.text:h.guaci, dy?dy.baihua:h.guaci_baihua, tag);
  }

  /* ---------- 全局点击委托 ---------- */
  document.addEventListener("click", function(ev){
    var b=ev.target&&ev.target.closest&&ev.target.closest("#xx-bar button");
    if(!b)return;
    var op=b.getAttribute("data-x");
    AAPT.buzz(10);
    if(op==="fav"){ var m=location.hash.match(/^#\/gua\/(\d+)/); if(m)toggleFav(+m[1]); }
    else if(op==="save"){
      var m2=location.hash.match(/^#\/gua\/(\d+)/); if(!m2)return;
      var h=hexByIdx(+m2[1]);
      AAPT.saveImage(drawCard(h,0,h.guaci,h.guaci_baihua,h.eyebrow), "签卡已存入相册");
    }
    else if(op==="post"){
      var m3=location.hash.match(/^#\/gua\/(\d+)/); if(!m3)return;
      var h3=hexByIdx(+m3[1]);
      var d=drawCard(h3,0,h3.guaci,h3.guaci_baihua,h3.eyebrow);
      AAPT.postNote({ title:("玄学口袋 · "+h3.title).slice(0,20),
        content:"翻开《周易》第"+h3.index+"卦「"+h3.title+"」。"+h3.guaci+" "+h3.guaci_baihua+"（传统文化娱乐参考）", image:d });
    }
    else if(op==="csave"){ var d2=castCard(); if(d2)AAPT.saveImage(d2,"签卡已存入相册"); }
    else if(op==="cpost"){
      var d3=castCard(); if(!d3)return;
      var b2=buildHex(lastCast.r.lower,lastCast.r.upper,lastCast.r.dong);
      var dy2=lastCast.r.dong?b2.hex.yaos[lastCast.r.dong-1]:null;
      AAPT.postNote({ title:("起得一卦 · "+b2.hex.title).slice(0,20),
        content:"梅花易数起得一卦：第"+b2.hex.index+"卦「"+b2.hex.title+"」。"+(dy2?dy2.text:b2.hex.guaci)+"（"+(lastCast.info&&lastCast.info.tag||"体用生克")+"）传统命理内容，仅作文化娱乐参考。", image:d3 });
    }
  });

  /* ---------- 包装 renderGua / showCastResult ---------- */
  var _renderGua = renderGua;
  renderGua = function(idx){ _renderGua(idx); setTimeout(function(){ onDetail(idx); }, 0); };
  var _showCastResult = showCastResult;
  showCastResult = function(r, info){ _showCastResult(r, info); setTimeout(function(){ onCast(r, info); }, 0); };
})();

})();
