/* AI修仙传 · 神魔卡册 · 移动端原生版
 * 还原固件核心：67 张卡（稀有度/四属性/翻面卡背）· 抽卡（单抽/十连/保底）
 *   · 书架阅读（2 本 157 章 · 断点续读）· 主线剧情（142 拍 · 调枢/擦灰/二选一）
 *   · 书卡联动（卡面出演章节 ↔ 剧情立绘 ↔ 原著）
 * 移动端新增：触控抽卡动画、真实卡面立绘、滚动阅读与进度持久化、图鉴收集统计。
 */
(function () {
  "use strict";
  var A = window.AAPT;
  var CARDS = window.AX_CARDS, RARITY = window.AX_RARITY, TYPE = window.AX_TYPE;
  var STORY = window.AX_STORY, BOOKS = window.AX_BOOKS;
  var BYOID = {};
  for (var ci = 0; ci < CARDS.length; ci++) { BYOID[CARDS[ci].oid] = CARDS[ci]; }

  var owned = {}, pity = 0, pulls = 0, storyProg = null, readProg = {};
  var curTab = "album", albumFilter = -1;

  /* ---------------- 存储 ---------------- */
  function loadAll(cb) {
    var todo = 4;
    function done() { if (--todo === 0) { cb(); } }
    A.getJSON("sm_owned", {}, function (v) { owned = v || {}; done(); });
    A.getJSON("sm_pity", { p: 0, t: 0 }, function (v) { pity = (v && v.p) || 0; pulls = (v && v.t) || 0; done(); });
    A.getJSON("sm_story", null, function (v) { storyProg = v; done(); });
    A.getJSON("sm_read", {}, function (v) { readProg = v || {}; done(); });
  }
  function saveOwned() { A.setJSON("sm_owned", owned); }
  function savePity() { A.setJSON("sm_pity", { p: pity, t: pulls }); }

  /* ---------------- 工具 ---------------- */
  function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function $(id) { return document.getElementById(id); }
  var toastT = null;
  function toast(msg) { A.toast(msg); }
  function ownCount(name) { return owned[name] || 0; }
  function ownedKinds() {
    var n = 0;
    for (var i = 0; i < CARDS.length; i++) { if (owned[CARDS[i].name]) { n++; } }
    return n;
  }

  /* ---------------- 标签页 ---------------- */
  var tabsBox = document.querySelector(".tabs");
  tabsBox.addEventListener("click", function (e) {
    var b = e.target.closest("button");
    if (!b) { return; }
    curTab = b.getAttribute("data-t");
    var bs = tabsBox.getElementsByTagName("button");
    for (var i = 0; i < bs.length; i++) { bs[i].className = bs[i] === b ? "on" : ""; }
    var ids = ["album", "books", "story", "about"];
    for (var j = 0; j < ids.length; j++) {
      $("pane-" + ids[j]).className = "pane" + (ids[j] === curTab ? "" : " hide");
    }
    if (curTab === "album") { renderAlbum(); }
    if (curTab === "books") { renderBooks(); }
    if (curTab === "story") { renderStory(); }
    if (curTab === "about") { renderAbout(); }
    A.buzz(6);
  });

  /* ---------------- 卡册 ---------------- */
  function renderAlbum() {
    var p = $("pane-album");
    var h = "";
    h += "<div class=\"gacha-bar\"><div class=\"l1\">收集 <b>" + ownedKinds() + "/" + CARDS.length +
      "</b> · 累计抽卡 <b>" + pulls + "</b> · 保底进度 <b>" + pity + "/10</b>（10 抽不出传说必出）</div>" +
      "<div class=\"pitybar\"><i style=\"width:" + Math.min(100, pity * 10) + "%\"></i></div>" +
      "<div style=\"margin-top:10px;display:-webkit-box;display:-ms-flexbox;display:flex\">" +
      "<button class=\"btn-g\" id=\"gTen\" type=\"button\" style=\"margin:0 8px 0 0\">十 连 抽</button>" +
      "<button class=\"btn-g o\" id=\"gOne\" type=\"button\" style=\"margin:0\">单 抽</button></div></div>";
    h += "<div class=\"chips\"><button data-f=\"-1\" class=\"" + (albumFilter === -1 ? "on" : "") + "\" type=\"button\">全部</button>";
    for (var r = 4; r >= 0; r--) {
      h += "<button data-f=\"" + r + "\" class=\"" + (albumFilter === r ? "on" : "") + "\" type=\"button\">" + RARITY[r] + "</button>";
    }
    h += "</div><div class=\"grid\">";
    for (var i = 0; i < CARDS.length; i++) {
      var c = CARDS[i];
      if (albumFilter >= 0 && c.rarity !== albumFilter) { continue; }
      var oc = ownCount(c.name);
      h += "<div class=\"cell" + (oc ? "" : " no") + "\" data-i=\"" + i + "\">" +
        "<img src=\"" + c.art + "\" alt=\"" + esc(c.name) + "\" loading=\"lazy\">" +
        "<span class=\"rr r" + c.rarity + "\">" + RARITY[c.rarity] + "</span>" +
        (oc > 1 ? "<span class=\"ct\">×" + oc + "</span>" : "") +
        "<div class=\"nm\">" + esc(c.name) + "</div></div>";
    }
    h += "</div>";
    p.innerHTML = h;
  }
  $("pane-album").addEventListener("click", function (e) {
    var g1 = e.target.closest("#gOne");
    if (g1) { doGacha(1); return; }
    var g10 = e.target.closest("#gTen");
    if (g10) { doGacha(10); return; }
    var f = e.target.closest(".chips button");
    if (f) { albumFilter = parseInt(f.getAttribute("data-f"), 10); renderAlbum(); return; }
    var cell = e.target.closest(".cell");
    if (cell) { openCard(CARDS[parseInt(cell.getAttribute("data-i"), 10)]); }
  });

  /* ---------------- 卡详情（翻面） ---------------- */
  function attrsHtml(c) {
    var h = "";
    for (var i = 0; i < 4; i++) {
      h += "<div class=\"ar\"><em>" + esc(c.tags[i]) + "</em><div class=\"bar\"><i style=\"width:" + c.attrs[i] + "%\"></i></div><b>" + c.attrs[i] + "</b></div>";
    }
    return h;
  }
  function actorChapters(c) {
    var out = [];
    for (var i = 0; i < STORY.length; i++) {
      if (STORY[i].actors.indexOf(c.oid) >= 0) { out.push(i); }
    }
    return out;
  }
  function openCard(c) {
    var old = $("ovl-card");
    if (old) { old.parentNode.removeChild(old); }
    var o = document.createElement("div");
    o.className = "ovl"; o.id = "ovl-card";
    var eps = actorChapters(c);
    var epHtml = "";
    if (eps.length) {
      epHtml = "<div style=\"margin-top:12px;font-size:12px;color:#8a7a5e\">出演章节</div><div class=\"cd-tags\">" +
        eps.map(function (ei) { return "<span data-ep=\"" + ei + "\" style=\"color:#e0c98a\">" + esc("G" + (ei < 12 ? zero2(ei + 1) : "14") + " · " + esc(STORY[ei].t)) + "</span>"; }).join("") + "</div>";
    }
    o.innerHTML = "<button class=\"x\" id=\"cdx\" type=\"button\">✕</button><div class=\"flipwrap\"><div class=\"flipinner\" id=\"flipinner\">" +
      "<div class=\"ffront\"><img src=\"" + c.art + "\" alt=\"" + esc(c.name) + "\"></div>" +
      "<div class=\"fback\"><div class=\"back\">" +
      "<div class=\"cd-name\">" + esc(c.name) + "<span style=\"font-size:11px;color:#6d6350;letter-spacing:1px;margin-left:8px\">" + esc(c.en) + "</span></div>" +
      "<div class=\"cd-sub\">" + esc(c.sub) + " · " + RARITY[c.rarity] + " · " + TYPE[c.type] + " · 战力 " + c.power + "</div>" +
      "<div class=\"cd-quote\">" + esc(c.quote) + "</div>" +
      "<div class=\"attr\">" + attrsHtml(c) + "</div>" +
      "<div class=\"cd-bio\">" + esc(c.bio) + "</div>" +
      "<div class=\"cd-flavor\">" + esc(c.flavor) + "</div>" +
      "<div class=\"cd-foot\">" + esc(c.foot) + "</div>" + epHtml +
      "</div></div></div></div>" +
      "<div class=\"cd-acts\" style=\"max-width:320px;margin:14px auto 0\">" +
      "<button id=\"cdFlip\" type=\"button\">翻面 ↻ 看设定</button>" +
      "<button id=\"cdClose\" type=\"button\">关 闭</button></div>";
    document.body.appendChild(o);
    A.buzz(8);
    o.addEventListener("click", function (e) {
      if (e.target === o) { close(); return; }
      if (e.target.closest("#cdx") || e.target.closest("#cdClose")) { close(); return; }
      if (e.target.closest("#cdFlip")) {
        var fi = $("flipinner");
        if (fi.className.indexOf(" f") >= 0) { fi.className = "flipinner"; }
        else { fi.className = "flipinner f"; }
        A.buzz(8);
        return;
      }
      var ep = e.target.closest("[data-ep]");
      if (ep) {
        close();
        openPlayer(parseInt(ep.getAttribute("data-ep"), 10), 0);
      }
    });
    function close() { if (o.parentNode) { o.parentNode.removeChild(o); } }
  }
  function zero2(n) { return (n < 10 ? "0" : "") + n; }

  /* ---------------- 抽卡 ---------------- */
  function rollRarity(force) {
    if (force >= 0) { return force; }
    var r = Math.random() * 100;
    if (r < 1) { return 4; }
    if (r < 6) { return 3; }
    if (r < 18) { return 2; }
    if (r < 45) { return 1; }
    return 0;
  }
  function pickOfRarity(rr) {
    var pool = [];
    for (var i = 0; i < CARDS.length; i++) { if (CARDS[i].rarity === rr) { pool.push(CARDS[i]); } }
    if (!pool.length) { return CARDS[Math.floor(Math.random() * CARDS.length)]; }
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function doGacha(n) {
    var res = [];
    var pityHit = false;
    for (var i = 0; i < n; i++) {
      var want = -1;
      pity++;
      if (pity >= 10) { want = 3; pityHit = true; }   /* 10 抽不出传说 → 保底 */
      var rr = rollRarity(want);
      if (rr >= 3) { pity = 0; }
      res.push(pickOfRarity(rr));
    }
    if (n === 10) {
      var hasHi = false;
      for (var j = 0; j < res.length; j++) { if (res[j].rarity >= 2) { hasHi = true; } }
      if (!hasHi) { res[res.length - 1] = pickOfRarity(2); }
    }
    pulls += n;
    for (var k = 0; k < res.length; k++) {
      owned[res[k].name] = ownCount(res[k].name) + 1;
    }
    saveOwned(); savePity();
    showGachaResult(res, pityHit);
    A.buzz([18, 40, 18]);
  }
  function showGachaResult(res, pityHit) {
    var old = $("ovl-gacha");
    if (old) { old.parentNode.removeChild(old); }
    var o = document.createElement("div");
    o.className = "ovl"; o.id = "ovl-gacha";
    var h = "<button class=\"x\" id=\"gx\" type=\"button\">✕</button>" +
      "<div style=\"text-align:center;margin:10px 0 16px\"><div style=\"font-size:19px;font-weight:700;letter-spacing:4px;color:#e0c98a\">抽 卡 结 果</div>" +
      (pityHit ? "<div style=\"font-size:11px;color:#d4879e;margin-top:4px\">保底触发 · 传说必出</div>" : "") + "</div><div class=\"gres\">";
    for (var i = 0; i < res.length; i++) {
      var c = res[i];
      h += "<div class=\"gc\" style=\"animation-delay:" + (i * 0.09) + "s\"><img src=\"" + c.art + "\" alt=\"\"><span class=\"rr r" + c.rarity + "\">" + RARITY[c.rarity] + "</span></div>";
    }
    h += "</div><div style=\"margin-top:14px;text-align:center;font-size:12px;color:#a2947a\">保底进度 " + pity + "/10 · 累计 " + pulls + " 抽 · 收集 " + ownedKinds() + "/" + CARDS.length + "</div>" +
      "<div class=\"cd-acts\" style=\"max-width:320px;margin:16px auto 0\"><button id=\"gAgain\" type=\"button\">再 来 一 组</button><button id=\"gOk\" type=\"button\">收 下</button></div>";
    o.innerHTML = h;
    document.body.appendChild(o);
    o.addEventListener("click", function (e) {
      if (e.target === o) { close(); renderAlbum(); return; }
      if (e.target.closest("#gx") || e.target.closest("#gOk")) { close(); renderAlbum(); return; }
      if (e.target.closest("#gAgain")) { close(); doGacha(res.length); return; }
      var gc = e.target.closest(".gc");
      if (gc) {
        var idx = Array.prototype.indexOf.call(gc.parentNode.children, gc);
        close();
        openCard(res[idx]);
        renderAlbum();
      }
    });
    function close() { if (o.parentNode) { o.parentNode.removeChild(o); } }
  }

  /* ---------------- 书架 / 阅读 ---------------- */
  function renderBooks() {
    var p = $("pane-books");
    var h = "";
    var last = readProg.last;
    if (last) {
      var bk = BOOKS[last.b], ck = bk && bk.chs[last.c];
      h += "<button class=\"btn-c cont\" id=\"btnResume\" type=\"button\">续读 · " + esc(bk ? bk.t : "") + " · " + esc(ck ? ck.t : "") + "</button>";
    }
    for (var i = 0; i < BOOKS.length; i++) {
      var b = BOOKS[i];
      var rp = readProg["b" + i];
      var pct = rp ? Math.min(100, Math.round(((rp.c || 0) + 1) * 100 / b.chs.length)) : 0;
      h += "<div class=\"book\"><h3>" + esc(b.t) + "</h3><div class=\"bs\">" + esc(b.sub) + " · " + b.chs.length + " 章</div>" +
        "<div class=\"bd\">" + esc(b.desc) + "</div>" +
        "<div class=\"bp\"><i style=\"width:" + pct + "%\"></i></div>" +
        "<div class=\"bmeta\">" + (rp ? "读到 " + esc(b.chs[rp.c || 0].t) : "尚未开始") + "</div>" +
        "<div style=\"margin-top:10px\"><button class=\"btn-c\" data-b=\"" + i + "\" type=\"button\">目 录</button></div></div>";
    }
    p.innerHTML = h;
  }
  $("pane-books").addEventListener("click", function (e) {
    if (e.target.closest("#btnResume")) {
      var l = readProg.last;
      if (l) { openReader(l.b, l.c); }
      return;
    }
    var bt = e.target.closest("[data-b]");
    if (bt) { openChapters(parseInt(bt.getAttribute("data-b"), 10)); }
  });
  function openChapters(bi) {
    var old = $("ovl-chs");
    if (old) { old.parentNode.removeChild(old); }
    var b = BOOKS[bi];
    var o = document.createElement("div");
    o.className = "ovl"; o.id = "ovl-chs";
    var rp = readProg["b" + bi] || {};
    var h = "<button class=\"x\" id=\"chx\" type=\"button\">✕</button>" +
      "<div style=\"text-align:center;margin:6px 0 14px\"><div style=\"font-size:18px;font-weight:700;color:#e0c98a;letter-spacing:2px\">" + esc(b.t) + "</div>" +
      "<div style=\"font-size:11px;color:#7d7260;margin-top:3px\">" + esc(b.sub) + " · 共 " + b.chs.length + " 章</div></div><div class=\"chl\">";
    for (var i = 0; i < b.chs.length; i++) {
      h += "<div class=\"ci" + (i <= (rp.c || -1) ? " read" : "") + "\" data-c=\"" + i + "\"><b>" + esc(b.chs[i].t) + "</b>" + (i === rp.c ? "<i>读到这</i>" : (i < (rp.c || -1) ? "<i>已读</i>" : "")) + "</div>";
    }
    h += "</div>";
    o.innerHTML = h;
    document.body.appendChild(o);
    o.addEventListener("click", function (e) {
      if (e.target.closest("#chx") || e.target === o) { o.parentNode.removeChild(o); return; }
      var ci = e.target.closest("[data-c]");
      if (ci) {
        o.parentNode.removeChild(o);
        openReader(bi, parseInt(ci.getAttribute("data-c"), 10));
      }
    });
  }
  var readerEl = null, saveTimer = null;
  function openReader(bi, ci) {
    closeReader();
    var b = BOOKS[bi], ch = b.chs[ci];
    readerEl = document.createElement("div");
    readerEl.className = "reader"; readerEl.id = "reader";
    readerEl.innerHTML = "<h2>" + esc(ch.t) + "</h2><div class=\"rm\">" + esc(b.t) + " · 第 " + (ci + 1) + "/" + b.chs.length + " 章</div>" +
      ch.p.map(function (t) { return "<p>" + esc(t) + "</p>"; }).join("") +
      "<div class=\"rbar\"><button id=\"rPrev\" type=\"button\">上一章</button><button id=\"rBack\" type=\"button\">回目录</button><button id=\"rNext\" type=\"button\">下一章</button></div>";
    document.body.appendChild(readerEl);
    var rp = readProg["b" + bi];
    if (rp && rp.c === ci && rp.sc) {
      setTimeout(function () { readerEl.scrollTop = rp.sc; }, 30);
    }
    readProg["b" + bi] = { c: ci, sc: 0 };
    readProg.last = { b: bi, c: ci };
    A.setJSON("sm_read", readProg);
    readerEl.addEventListener("scroll", function () {
      if (saveTimer) { return; }
      saveTimer = setTimeout(function () {
        saveTimer = null;
        readProg["b" + bi] = { c: ci, sc: readerEl.scrollTop };
        A.setJSON("sm_read", readProg);
      }, 700);
    });
    readerEl.addEventListener("click", function (e) {
      if (e.target.closest("#rBack")) { saveNow(); closeReader(); renderBooks(); return; }
      if (e.target.closest("#rPrev")) { saveNow(); if (ci > 0) { openReader(bi, ci - 1); } else { toast("已是第一章"); } return; }
      if (e.target.closest("#rNext")) {
        saveNow();
        if (ci + 1 < b.chs.length) { openReader(bi, ci + 1); }
        else { toast("已是最新章节 · 连载中"); }
      }
    });
    function saveNow() {
      readProg["b" + bi] = { c: ci, sc: readerEl.scrollTop };
      A.setJSON("sm_read", readProg);
    }
  }
  function closeReader() {
    if (readerEl && readerEl.parentNode) { readerEl.parentNode.removeChild(readerEl); }
    readerEl = null;
  }

  /* ---------------- 主线剧情 ---------------- */
  function renderStory() {
    var p = $("pane-story");
    var h = "<div style=\"font-size:12px;color:#8a7a5e;margin-bottom:10px\">固件原装 13 幕剧情 · 142 拍 · 章中藏着调枢、擦灰、二选一三道关</div>";
    var cur = storyProg ? storyProg.ch : -1, curB = storyProg ? storyProg.beat : 0;
    if (storyProg) {
      h += "<button class=\"btn-c cont\" id=\"stResume\" type=\"button\">继续 · " + esc(STORY[storyProg.ch].t) + "（第 " + (storyProg.beat + 1) + "/" + STORY[storyProg.ch].beats.length + " 拍）</button>";
    }
    for (var i = 0; i < STORY.length; i++) {
      var s = STORY[i];
      var tag = "G" + (i < 12 ? zero2(i + 1) : "14");
      var ar = s.actors.slice(0, 3).map(function (oid) {
        var c = BYOID[oid];
        return c ? "<img src=\"" + c.art + "\" alt=\"\">" : "";
      }).join("");
      h += "<div class=\"stch\" data-ch=\"" + i + "\"><div class=\"gi\">" + tag + "</div><div class=\"tt\"><b>" + esc(s.t) + "</b><div>" + s.count + " 拍" +
        (i === cur ? " · 读到第 " + (curB + 1) + " 拍" : "") + "</div></div><div class=\"ar\">" + ar + "</div></div>";
    }
    p.innerHTML = h;
  }
  $("pane-story").addEventListener("click", function (e) {
    if (e.target.closest("#stResume")) { openPlayer(storyProg.ch, storyProg.beat); return; }
    var el = e.target.closest("[data-ch]");
    if (el) { openPlayer(parseInt(el.getAttribute("data-ch"), 10), 0); }
  });

  var plEl = null;
  function openPlayer(chi, bi) {
    closePlayer();
    plEl = document.createElement("div");
    plEl.className = "player"; plEl.id = "player";
    plEl.innerHTML = "<div class=\"pl-top\"><button id=\"plBack\" type=\"button\">退出</button><div class=\"tt\"></div><div class=\"pc\"></div></div>" +
      "<div class=\"pl-stage\"><div class=\"pl-art\"><div class=\"noart\">AI 修 仙 传</div></div><div class=\"pl-name hide\"></div></div>" +
      "<div style=\"padding:0 14px calc(16px + env(safe-area-inset-bottom))\"><div class=\"pl-text\"></div><button class=\"pl-next hide\" id=\"plNext\" type=\"button\">继 续</button><div class=\"pl-game hide\" id=\"plGame\"></div></div>";
    document.body.appendChild(plEl);
    plEl._chi = chi;
    showBeat(chi, bi);
    plEl.addEventListener("click", function (e) {
      if (e.target.closest("#plBack")) { closePlayer(); renderStory(); return; }
      if (e.target.closest("#plNext")) {
        var st = plEl._st;
        A.buzz(6);
        showBeat(st.chi, st.bi + 1);
        return;
      }
      var art = e.target.closest(".pl-art img");
      if (art && plEl._who != null && BYOID[plEl._who]) {
        openCard(BYOID[plEl._who]);
      }
    });
  }
  function closePlayer() {
    if (plEl && plEl.parentNode) { plEl.parentNode.removeChild(plEl); }
    plEl = null;
  }
  function saveStory(chi, bi) {
    storyProg = { ch: chi, beat: bi };
    A.setJSON("sm_story", storyProg);
  }
  function showBeat(chi, bi) {
    if (!plEl) { return; }
    var s = STORY[chi];
    if (bi >= s.beats.length) {
      plEl._st = { chi: chi, bi: bi };
      plEl.querySelector(".tt").textContent = s.t;
      plEl.querySelector(".pc").textContent = "完";
      plEl.querySelector(".pl-text").innerHTML = "<b style=\"color:#e0c98a\">「" + esc(s.t) + "」完</b><br><span style=\"font-size:13px;color:#a2947a\">下一幕还在后面的宇宙里等你。</span>";
      var nx = $("plNext");
      nx.className = "pl-next"; nx.textContent = (chi + 1 < STORY.length) ? "下 一 幕" : "回 目 录";
      nx.onclick = function () {
        closePlayer();
        if (chi + 1 < STORY.length) { openPlayer(chi + 1, 0); } else { renderStory(); }
      };
      plEl.querySelector(".pl-game").className = "pl-game hide";
      plEl.querySelector(".pl-art").innerHTML = "<div class=\"noart\">幕 终</div>";
      return;
    }
    var b = s.beats[bi];
    saveStory(chi, bi);
    plEl._st = { chi: chi, bi: bi };
    plEl.querySelector(".tt").textContent = s.t;
    plEl.querySelector(".pc").textContent = (bi + 1) + "/" + s.count;
    var art = plEl.querySelector(".pl-art");
    var nm = plEl.querySelector(".pl-name");
    if (b.who !== 255 && BYOID[b.who]) {
      var c = BYOID[b.who];
      plEl._who = b.who;
      art.innerHTML = "<img src=\"" + c.art + "\" alt=\"\">";
      nm.className = "pl-name"; nm.textContent = c.name;
    } else if (b.who === 255 && plEl._who != null && BYOID[plEl._who]) {
      var c2 = BYOID[plEl._who];
      art.innerHTML = "<img src=\"" + c2.art + "\" alt=\"\">";
      nm.className = "pl-name"; nm.textContent = c2.name;
    } else {
      plEl._who = null;
      art.innerHTML = "<div class=\"noart\">AI 修 仙 传</div>";
      nm.className = "pl-name hide";
    }
    var tx = plEl.querySelector(".pl-text");
    var nx = $("plNext");
    var gm = plEl.querySelector(".pl-game");
    nx.className = "pl-next hide";
    gm.className = "pl-game hide";
    if (b.k === "s") {
      tx.innerHTML = "<span style=\"color:#e0c98a\">" + esc(b.line).replace(/\n/g, "<br>") + "</span>";
    } else {
      tx.innerHTML = esc(b.line).replace(/\n/g, "<br>");
    }
    if (b.k === "p") {
      if (b.play === 2) { gameWipe(gm, function () { A.buzz([16, 30, 16]); showBeat(chi, bi + 1); }); }
      else if (b.play === 1) { gameTune(gm, function () { A.buzz([16, 30, 16]); showBeat(chi, bi + 1); }); }
      else if (b.play === 3) { gamePick(gm, function () { showBeat(chi, bi + 1); }); }
      else { nx.className = "pl-next"; nx.textContent = "继 续"; }
    } else {
      nx.className = "pl-next";
      nx.textContent = (bi + 1 === s.beats.length) ? "幕 终" : "继 续";
    }
  }

  /* --- 关卡：擦灰 --- */
  function gameWipe(box, done) {
    box.className = "pl-game";
    box.innerHTML = "<h4>交互 · 擦灰</h4><p>手指在灰面上来回擦，把底下的字擦出来（进度过半即可）。</p>" +
      "<div class=\"wipebox\"><div class=\"wipe-under\">天门是焊死的盒子<br>从来没有人回来过</div><canvas id=\"wipeCv\"></canvas></div>" +
      "<div class=\"tune-fb\" id=\"wipeFb\">已擦开 0%</div>";
    var cv = box.querySelector("#wipeCv");
    var wrap = box.querySelector(".wipebox");
    setTimeout(function () {
      var w = wrap.clientWidth, hh = wrap.clientHeight;
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = w * dpr; cv.height = hh * dpr;
      var x = cv.getContext("2d");
      x.setTransform(dpr, 0, 0, dpr, 0, 0);
      var gd = x.createLinearGradient(0, 0, w, hh);
      gd.addColorStop(0, "#4a4238"); gd.addColorStop(1, "#332c24");
      x.fillStyle = gd; x.fillRect(0, 0, w, hh);
      x.fillStyle = "rgba(255,255,255,.06)";
      for (var i = 0; i < 60; i++) { x.fillRect(Math.random() * w, Math.random() * hh, 2, 2); }
      var GX = 24, GY = 13, cleared = {};
      var total = GX * GY, n = 0, active = false;
      function mark(px, py) {
        var gx = Math.floor(px / w * GX), gy = Math.floor(py / hh * GY);
        for (var dx = -1; dx <= 1; dx++) {
          for (var dy = -1; dy <= 1; dy++) {
            var key = (gx + dx) + "_" + (gy + dy);
            if (gx + dx >= 0 && gx + dx < GX && gy + dy >= 0 && gy + dy < GY && !cleared[key]) {
              cleared[key] = 1; n++;
            }
          }
        }
        x.globalCompositeOperation = "destination-out";
        x.beginPath(); x.arc(px, py, 22, 0, Math.PI * 2); x.fill();
        x.globalCompositeOperation = "source-over";
        var pct = Math.round(n * 100 / total);
        box.querySelector("#wipeFb").textContent = "已擦开 " + pct + "%";
        if (n / total >= 0.55) { box.querySelector("#wipeFb").textContent = "擦开了 · 字浮出来了"; setTimeout(done, 700); }
      }
      function pos(e) {
        var r = cv.getBoundingClientRect();
        var t = e.touches ? e.touches[0] : e;
        return { x: t.clientX - r.left, y: t.clientY - r.top };
      }
      cv.addEventListener("touchstart", function (e) { e.preventDefault(); active = true; var p = pos(e); mark(p.x, p.y); }, { passive: false });
      cv.addEventListener("touchmove", function (e) { if (!active) { return; } e.preventDefault(); var p = pos(e); mark(p.x, p.y); }, { passive: false });
      cv.addEventListener("touchend", function () { active = false; });
      cv.addEventListener("mousedown", function (e) { active = true; var p = pos(e); mark(p.x, p.y); });
      cv.addEventListener("mousemove", function (e) { if (active) { var p = pos(e); mark(p.x, p.y); } });
      window.addEventListener("mouseup", function () { active = false; });
    }, 60);
  }

  /* --- 关卡：调枢 --- */
  function gameTune(box, done) {
    box.className = "pl-game";
    var target = 28 + Math.floor(Math.random() * 44);
    box.innerHTML = "<h4>交互 · 调枢</h4><p>金色是沉、蓝色是活。拖动滑杆让两股力量平衡，然后试着锚定——差得远会散，压得狠会僵。</p>" +
      "<div class=\"tune-row\"><em class=\"jin\">金</em><input id=\"tuneR\" type=\"range\" min=\"0\" max=\"100\" value=\"50\"><em class=\"lan\">蓝</em></div>" +
      "<div class=\"tune-fb\" id=\"tuneFb\">凭感觉，先试一次</div>" +
      "<button class=\"pl-next\" id=\"tuneGo\" type=\"button\" style=\"margin:8px 0 0\">锚 定</button>";
    var r = box.querySelector("#tuneR");
    var fb = box.querySelector("#tuneFb");
    box.querySelector("#tuneGo").addEventListener("click", function () {
      var d = parseInt(r.value, 10) - target;
      if (Math.abs(d) <= 3) {
        fb.textContent = "嗡——锚定了。两股力量咬合在一起。";
        A.buzz([20, 40, 20]);
        setTimeout(done, 900);
      } else if (d < -12) { fb.textContent = "太散了……水快成雾了，往回调。"; A.buzz(10); }
      else if (d < 0) { fb.textContent = "散了。活的那股占了上风。"; A.buzz(8); }
      else if (d > 12) { fb.textContent = "僵了。沉的那股太重，要冻住了。"; A.buzz(8); }
      else { fb.textContent = "稳过头了，反而像块死铁——差一点。"; A.buzz(8); }
    });
  }

  /* --- 关卡：二选一 --- */
  function gamePick(box, done) {
    box.className = "pl-game";
    box.innerHTML = "<h4>交互 · 抉择</h4><p>这个问题会决定你往后的路。</p>" +
      "<div class=\"pick-row\"><button data-p=\"0\" type=\"button\">问 出 口</button><button data-p=\"1\" type=\"button\">把 话 咽 回 去</button></div>";
    box.addEventListener("click", function (e) {
      var b = e.target.closest("[data-p]");
      if (!b) { return; }
      toast(b.getAttribute("data-p") === "0" ? "你问出了那句话 —— 有些路，从这里开始" : "你把话咽了回去 —— 但问题在心里生了根");
      done();
    }, { once: true });
  }

  /* ---------------- 关于 ---------------- */
  function renderAbout() {
    $("pane-about").innerHTML =
      "<div class=\"gacha-bar\"><div class=\"l1\" style=\"line-height:1.9\">" +
      "《AI修仙传 · 神魔卡册》—— 把「抽卡收集」和「读一部原创长篇」装进同一个工具。</div></div>" +
      "<div class=\"book\"><h3>卡册</h3><div class=\"bd\">" + CARDS.length + " 张卡，" +
      "神话 / 传说 / 史诗 / 稀有 / 普通五档稀有度。点卡面看立绘，翻面看人物设定、四项属性与出演章节。单抽、十连，连续 10 抽不出传说必出保底，收集进度自动记住。</div></div>" +
      "<div class=\"book\"><h3>书架</h3><div class=\"bd\">内置原创长篇《AI修仙传》：第一部《焊死的盒子》" + BOOKS[0].chs.length + " 章 + 第二部《道枢之战》连载。每翻一次自动记住位置，随时续读。</div></div>" +
      "<div class=\"book\"><h3>主线</h3><div class=\"bd\">13 幕剧情、142 拍，全部取自小说原文。章中藏着三道关：擦灰见字、调枢锚定、问或不问。点立绘可跳卡面，卡面可跳回剧情——书卡联动。</div></div>" +
      "<div class=\"empty\" style=\"margin-top:14px\">全部内容为原创小说《AI修仙传》 · 纯离线 · 无网络权限</div>";
  }

  /* ---------------- 启动 ---------------- */
  loadAll(function () {
    renderAlbum();
  });
  window.SM = { openCard: openCard, doGacha: doGacha, openReader: openReader, openPlayer: openPlayer, stat: function () { return { owned: ownedKinds(), pity: pity, pulls: pulls }; } };
})();
