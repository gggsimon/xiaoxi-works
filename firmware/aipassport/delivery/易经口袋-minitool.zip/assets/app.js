/* 易经口袋 app — 卦盘 / 梅花起卦 / 铜钱摇卦（ES2017，事件委托，无内联事件） */
(function () {
  "use strict";
  var $ = function (s) { return document.querySelector(s); };
  var viewEl = document.getElementById("view");
  var TRI_WX = { 乾: "金", 兑: "金", 离: "火", 震: "木", 巽: "木", 坎: "水", 艮: "土", 坤: "土" };
  var state = { filterSec: "all", lastCast: null };

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
  function hexByIdx(i) { for (var k = 0; k < HEX_DATA.length; k++) if (HEX_DATA[k].index === i) return HEX_DATA[k]; return null; }

  /* ---------- 卦画 ---------- */
  function glHtml(bottomUp, hlPos) {
    var h = '<div class="gl">';
    for (var i = 0; i < 6; i++) {
      var yang = bottomUp[i] === 1, hl = (hlPos && i + 1 === hlPos);
      if (yang) h += '<i' + (hl ? ' style="background:#e6c37f;box-shadow:0 0 5px rgba(230,195,127,.8)"' : '') + '></i>';
      else h += '<i class="yin"' + (hl ? ' style="background:none"' : '') + '><b style="background:' + (hl ? "#e6c37f" : "") + '"></b><b style="background:' + (hl ? "#e6c37f" : "") + '"></b></i>';
    }
    return h + "</div>";
  }

  /* ---------- 卦盘 ---------- */
  function renderPan() {
    var list = HEX_DATA.slice();
    if (state.filterSec !== "all") {
      list = list.filter(function (h) { return state.filterSec === "up" ? h.index <= 30 : h.index > 30; });
    }
    var cells = list.map(function (h) {
      var bu = h.lines_top_down.slice().reverse();
      return '<div class="hex-cell" data-idx="' + h.index + '">' +
        '<div class="no">' + h.index + '</div>' + glHtml(bu) +
        '<div class="nm">' + esc(h.title.replace(/为|之/g, "")) + '</div></div>';
    }).join("");
    viewEl.innerHTML =
      '<div class="card"><h2>六十四卦卦盘</h2>' +
      '<div class="filters">' +
      '<button data-f="all" class="on">全部</button><button data-f="up">上经 1-30</button><button data-f="down">下经 31-64</button>' +
      '</div><div class="grid">' + cells + '</div></div>' +
      '<div class="foot">点击任一卦读卦辞 · 彖 · 大象 · 六爻详解</div>';
  }

  /* ---------- 详解 ---------- */
  function renderGua(idx) {
    var h = hexByIdx(idx);
    if (!h) { setView("pan"); return; }
    var bu = h.lines_top_down.slice().reverse();
    var yaos = h.yaos.map(function (y, i) {
      var isYang = y.label.indexOf("阳") >= 0 || y.label.indexOf("九") >= 0;
      return '<li class="yao-item">' +
        '<div class="yao-top"><span class="yao-label">' + esc(y.label) + '</span>' +
        '<span class="tag">' + (isYang ? "阳" : "阴") + '</span>' +
        '<span class="yao-type">' + esc((y.type || "").split("/")[0]) + '</span></div>' +
        '<div class="yao-text">' + esc(y.text) + '</div>' +
        '<div class="yao-baihua">' + esc(y.baihua) + '</div>' +
        (y.xiaoxiang ? '<div class="yao-xx">' + esc(y.xiaoxiang) + '</div>' : '') +
        '</li>';
    }).join("");
    var scripture = (h.scriptures || []).map(function (s) {
      return "<blockquote><b>" + esc(s.name) + "</b>　" + esc(s.text) + "</blockquote>";
    }).join("");
    viewEl.innerHTML =
      '<div class="card">' +
      '<div class="hexhead"><div style="width:52px">' + glHtml(bu) + '</div>' +
      '<div><div class="big">第' + h.index + '卦 · ' + esc(h.title) + '</div>' +
      '<div class="meta">' + esc(h.eyebrow) + '</div></div></div>' +
      '<div class="guaci">' + esc(h.guaci) + '</div>' +
      '<div class="baihua">' + esc(h.guaci_baihua) + '</div>' +
      scripture +
      '<h2 style="margin-top:14px">六 爻</h2><ul style="list-style:none">' + yaos + '</ul>' +
      (h.special && h.special.length ? '<h2 style="margin-top:8px">用 九 用 六</h2><div class="hint">' + esc(typeof h.special[0] === 'string' ? h.special[0] : (h.special[0].text || '')) + '</div>' : '') +
      '<div class="actions">' +
      '<button data-x="fav" data-i="' + h.index + '">☆ 收 藏</button>' +
      '<button data-x="save" data-i="' + h.index + '">存 签 卡</button>' +
      '<button data-x="post" data-i="' + h.index + '">发笔记</button>' +
      '</div></div>' +
      '<div class="foot">传统文化娱乐参考</div>';
    refreshFavBtn(h.index);
    AAPT.pushHistory("yj_history", { t: "第" + h.index + "卦 · " + h.title, i: h.index, ts: Date.now() }, 30, function () {});
  }

  /* ---------- 梅花起卦 ---------- */
  function shichenNum(d) { return Math.floor(((d.getHours() + 1) % 24) / 2) + 1; }
  function castByTime() {
    var now = new Date();
    var lunar = Lunar.fromDate(now);
    var zhiN = lunar.getYearInGanZhiExact();
    var yearN = ((lunar.getYear() - 4) % 12 + 12) % 12 + 1;   /* 地支序：子1…亥12 */
    var m = lunar.getMonth(), d = lunar.getDay(), sc = shichenNum(now);
    var up = (yearN + m + d) % 8, down = (yearN + m + d + sc) % 8, dong = (yearN + m + d + sc) % 6;
    if (up === 0) up = 8; if (down === 0) down = 8; if (dong === 0) dong = 6;
    return { up: up, down: down, dong: dong, tag: "时间起卦 · " + lunar.getYearInGanZhi() + "年" + lunar.getMonthInChinese() + "月" + lunar.getDayInChinese() + " " + "子丑寅卯辰巳午未申酉戌亥"[sc - 1] + "时" };
  }
  var TRI_BY_NUM = { 1: "乾", 2: "兑", 3: "离", 4: "震", 5: "巽", 6: "坎", 7: "艮", 8: "坤" };
  function coinToss() {
    var s = 0, faces = [];
    for (var i = 0; i < 3; i++) { var f = Math.random() < 0.5 ? 3 : 2; s += f; faces.push(f === 3 ? "字" : "背"); }
    return { s: s, faces: faces, yang: s === 7 || s === 9, moving: s === 6 || s === 9 };
  }
  function linesToHex(lines) { /* lines: [初..上] 1阳0阴 */
    var lo = lines[0] + 2 * lines[1] + 4 * lines[2], hi = lines[3] + 2 * lines[4] + 4 * lines[5];
    var key = lo + 8 * hi;
    for (var i = 0; i < HEX_DATA.length; i++) {
      var h = HEX_DATA[i], bu = h.lines_top_down.slice().reverse();
      var l2 = bu[0] + 2 * bu[1] + 4 * bu[2], h2 = bu[3] + 2 * bu[4] + 4 * bu[5];
      if (l2 + 8 * h2 === key) return h;
    }
    return null;
  }
  function triNameOf(h, which) { /* which: 'lower'|'upper' */
    var t = h.eyebrow.split("·")[1] || h.eyebrow; /* 形如 上经 · 乾下乾上 */
    var m = (h.meta || "").match(/^(..)下(..)上$/) || (h.eyebrow.match(/([乾坤震巽坎离艮兑])下([乾坤震巽坎离艮兑])/) || [])[0];
    var s = (h.meta || "").replace(/\s/g, "");
    var mm = s.match(/^(..?)下(..?)上$/);
    var lower = mm ? mm[1] : "", upper = mm ? mm[2] : "";
    if (!lower) {
      mm = h.eyebrow.replace(/^.*·\s*/, "").match(/^(..?)下(..?)上$/);
      lower = mm ? mm[1] : ""; upper = mm ? mm[2] : "";
    }
    return which === "lower" ? lower : upper;
  }
  function shengKeName(yong, ti) {
    var GEN = { 木: "火", 火: "土", 土: "金", 金: "水", 水: "木" }, KO = { 木: "土", 土: "水", 水: "火", 火: "金", 金: "木" };
    if (yong === ti) return "比和";
    if (GEN[yong] === ti) return "用生体";
    if (GEN[ti] === yong) return "体生用";
    if (KO[yong] === ti) return "用克体";
    if (KO[ti] === yong) return "体克用";
    return "比和";
  }
  var KEJU = {
    "用生体": { t: "顺 · 外力来助", c: "所问之事有人送力上门，气场向着你，宜顺势接住，把事情往前推。", good: 1 },
    "体克用": { t: "得力 · 可掌控", c: "主动权在你手里，事情拿得住，但要自己出力去推动，稳着来即可。", good: 1 },
    "比和":   { t: "持平 · 可缓图", c: "双方势均，局面不急不躁，按部就班推进最合适。", good: 0 },
    "体生用": { t: "耗 · 付出多", c: "这段时间你在往外付出，精力容易外泄，量力而行，别硬撑。", good: -1 },
    "用克体": { t: "承压 · 宜守", c: "外部压力暂时大过你的势头，宜守不宜进，先稳住阵脚再图下一步。", good: -1 }
  };
  function showCast(ben, dong, tag) {
    var bu = ben.lines_top_down.slice().reverse();
    var lowerT = triNameOf(ben, "lower"), upperT = triNameOf(ben, "upper");
    var tiT = dong <= 3 ? upperT : lowerT, yongT = dong <= 3 ? lowerT : upperT;
    var tiW = TRI_WX[tiT], yongW = TRI_WX[yongT];
    var sk = shengKeName(yongW, tiW), kj = KEJU[sk];
    /* 互卦：234爻为下，345爻为上 */
    var huLines = [bu[1], bu[2], bu[3], bu[2], bu[3], bu[4]];
    var huHex = linesToHex(huLines);
    /* 变卦 */
    var bianLines = bu.slice(), bianHex = null;
    if (dong >= 1 && dong <= 6) { bianLines[dong - 1] = bianLines[dong - 1] === 1 ? 0 : 1; bianHex = linesToHex(bianLines); }
    var dy = dong ? ben.yaos[dong - 1] : null;
    state.lastCast = { ben: ben, dong: dong, tag: tag };
    AAPT.pushHistory("yj_casts", { t: ben.title + (dong ? " · 动爻" + dong : " · 静卦"), i: ben.index, d: dong, ts: Date.now() }, 30, function () {});
    viewEl.innerHTML =
      '<div class="card">' +
      '<h2>' + esc(tag) + '</h2>' +
      '<div class="hexhead"><div style="width:56px">' + glHtml(bu, dong) + '</div>' +
      '<div><div class="big">本卦 · ' + esc(ben.title) + '</div>' +
      '<div class="meta">第' + ben.index + '卦' + (dong ? ' · 朱金标出的是动爻（第' + dong + '爻）' : ' · 六爻安静') + '</div></div></div>' +
      '<div class="guaci">' + esc(ben.guaci) + '</div>' +
      '<div class="baihua">' + esc(ben.guaci_baihua) + '</div>' +
      '<h2 style="margin-top:14px">体 用 生 克</h2>' +
      '<div class="res-line">体 <b>' + tiT + '(' + tiW + ')</b> 代表你 · 用 <b>' + yongT + '(' + yongW + ')</b> 代表所问的事</div>' +
      '<div class="res-line" style="margin-top:6px">' + sk + ' → <b>' + kj.t + '</b></div>' +
      '<div class="hint" style="margin-top:5px">' + kj.c + '</div>' +
      '<h2 style="margin-top:14px">互 卦 · 过程</h2>' +
      '<div class="res-line">' + (huHex ? '<b>' + esc(huHex.title) + '</b>（第' + huHex.index + '卦）' : '—') + '：事情中间的走势，藏在这一卦里。</div>' +
      '<h2 style="margin-top:14px">变 卦 · 结局</h2>' +
      '<div class="res-line">' + (bianHex ? '<b>' + esc(bianHex.title) + '</b>（第' + bianHex.index + '卦）' : '六爻安静，以本卦论。') + (dong ? '：动爻落地后的走向。</div><div class="hint" style="margin-top:4px">' + esc(dy ? dy.text + "　" + dy.baihua : "") + '</div>' : '</div>') +
      '<div class="actions">' +
      '<button data-x="csave">存 签 卡</button><button data-x="cpost">发笔记</button>' +
      '</div></div>' +
      '<div class="foot">梅花易数体用分析法 · 传统文化娱乐参考，不作吉凶断言</div>';
  }

  function renderCast() {
    var now = new Date();
    var lunar = Lunar.fromDate(now);
    viewEl.innerHTML =
      '<div class="card"><h2>起 一 卦</h2>' +
      '<div class="hint">梅花易数：按当下时间起，或亲手摇六爻。动爻是整卦的开关，体用五行看局面顺逆。</div>' +
      '<button class="castbtn gold" id="btn-time">按 此 刻 起 卦</button>' +
      '<div class="hint" style="margin-top:8px;text-align:center">' + esc(lunar.getYearInGanZhi() + "年 " + lunar.getMonthInChinese() + "月" + lunar.getDayInChinese() + " · 此刻" + "子丑寅卯辰巳午未申酉戌亥"[shichenNum(now) - 1] + "时") + '</div>' +
      '<h2 style="margin-top:18px">铜 钱 摇 卦</h2>' +
      '<div class="coins" id="coins"><div class="coin">?</div><div class="coin">?</div><div class="coin">?</div></div>' +
      '<div class="hint" id="coin-tip" style="text-align:center">点铜钱掷一次，摇满六爻自动成卦</div>' +
      '<div id="tossed"></div>' +
      '<button class="castbtn" id="btn-reset">重 新 摇</button>' +
      '</div>' +
      '<div class="foot">起卦结果会保存在本机「说明」页可回看</div>';
    var lines = [], tossed = 0;
    document.getElementById("btn-time").addEventListener("click", function () {
      AAPT.buzz(12);
      var r = castByTime();
      /* num→trigram: 乾1兑2离3震4巽5坎6艮7坤8 → 用本卦反查：以上下卦找卦 */
      var ben = findByTrigrams(TRI_BY_NUM[r.down], TRI_BY_NUM[r.up]);
      if (ben) showCast(ben, r.dong, r.tag);
    });
    var coinEls = document.querySelectorAll("#coins .coin");
    document.getElementById("coins").addEventListener("click", function () {
      if (tossed >= 6) return;
      AAPT.buzz(10);
      var t = coinToss();
      lines.push(t.yang ? 1 : 0); tossed++;
      for (var i = 0; i < 3; i++) {
        coinEls[i].textContent = t.faces[i];
        coinEls[i].classList.remove("hot");
        void coinEls[i].offsetWidth;
        coinEls[i].classList.add("hot");
      }
      var names = ["初爻", "二爻", "三爻", "四爻", "五爻", "上爻"];
      document.getElementById("coin-tip").textContent = names[tossed - 1] + " · " + (t.yang ? "阳" : "阴") + (t.moving ? " · 动" : "");
      var row = document.createElement("div");
      row.className = "yaorow";
      row.innerHTML = '<span class="lab">' + names[tossed - 1] + '</span><span>' + t.faces.join(" ") + '</span><span style="margin-left:auto;color:' + (t.moving ? "#c0563e" : "#8d94a1") + '">' + (t.yang ? "阳" : "阴") + (t.moving ? " · 动爻" : "") + '</span>';
      document.getElementById("tossed").appendChild(row);
      if (tossed === 6) {
        var ben = linesToHex(lines);
        if (ben) setTimeout(function () {
          var dong = 0;
          /* 铜钱多动爻取第一个动爻；全静取0 */
          var recast = [];
          /* 重掷太复杂：以记录的第 t.moving 的第一爻为准 —— 保存 moving 信息 */
          showCast(ben, lastMoving(), "铜钱摇卦");
        }, 500);
      }
    });
    var movingFlags = [];
    var _coinToss = coinToss;
    document.getElementById("btn-reset").addEventListener("click", function () {
      lines = []; tossed = 0; movingFlags = [];
      document.getElementById("tossed").innerHTML = "";
      document.getElementById("coin-tip").textContent = "点铜钱掷一次，摇满六爻自动成卦";
      for (var i = 0; i < 3; i++) coinEls[i].textContent = "?";
    });
    /* 记录动爻 */
    function lastMoving() {
      var d = 0;
      var rows = document.querySelectorAll("#tossed .yaorow span:last-child");
      return window.__movingIdx || 0;
    }
    window.__movingIdx = 0;
    var _origAppend = null;
  }
  /* 记录动爻：在 coins click 里补写 */
  function findByTrigrams(lowerName, upperName) {
    for (var i = 0; i < HEX_DATA.length; i++) {
      var h = HEX_DATA[i];
      if (triNameOf(h, "lower") === lowerName && triNameOf(h, "upper") === upperName) return h;
    }
    return null;
  }

  /* ---------- 说明 ---------- */
  function renderAbout() {
    viewEl.innerHTML =
      '<div class="card"><h2>易 经 口 袋</h2>' +
      '<div class="hint">六十四卦随身带：卦盘逐卦读原文与白话；梅花易数按此刻起卦，或铜钱亲手摇满六爻。<br><br>' +
      '你的起卦与浏览记录保存在本机，下次打开还在。<br><br>' +
      'AI Passport 同名玩法的手机版——原本是掌上设备里的一枚离线六十四卦，如今装进你的手机，一样不联网。</div></div>' +
      '<div class="card"><h2>最近起卦</h2><div id="his-cast"></div></div>' +
      '<div class="card"><h2>最近浏览</h2><div id="his-view"></div></div>';
    AAPT.getJSON("yj_casts", [], function (a) {
      var el = document.getElementById("his-cast"); if (!el) return;
      el.innerHTML = (a && a.length) ? a.slice(0, 8).map(function (r) {
        return '<div class="yaorow"><span>' + esc(r.t) + '</span><span style="margin-left:auto;color:var(--mute)">' + (r.i ? '<a href="#/gua/' + r.i + '" style="color:#c9a050;text-decoration:none">回看</a>' : "") + '</span></div>';
      }).join("") : '<div class="empty">还没有起过卦。去「起卦」摇一卦。</div>';
    });
    AAPT.getJSON("yj_history", [], function (a) {
      var el = document.getElementById("his-view"); if (!el) return;
      el.innerHTML = (a && a.length) ? a.slice(0, 8).map(function (r) {
        return '<div class="yaorow"><span>' + esc(r.t) + '</span><span style="margin-left:auto"><a href="#/gua/' + r.i + '" style="color:#c9a050;text-decoration:none">回看</a></span></div>';
      }).join("") : '<div class="empty">还没有浏览记录。</div>';
    });
  }

  /* ---------- 签卡 ---------- */
  function guaDrawCard(x, bu, dong, cx, top, w) {
    var lh = Math.round(w / 3.8), bh = Math.round(lh * 0.4);
    for (var i = 0; i < 6; i++) {
      var yang = bu[i] === 1, y = top + (5 - i) * lh, hl = (i + 1 === dong);
      x.fillStyle = hl ? "#e6c37f" : "#e6e1d3";
      if (yang) x.fillRect(cx - w / 2, y, w, bh);
      else { var seg = Math.round(w * 0.4), gap = Math.round(w * 0.2); x.fillRect(cx - w / 2, y, seg, bh); x.fillRect(cx + w / 2 - seg, y, seg, bh); }
    }
  }
  function wrap(x, text, cx, y, maxW, lh, maxLines) {
    var line = "", lines = [];
    for (var i = 0; i < text.length; i++) { var ch = text[i];
      if (line && x.measureText(line + ch).width > maxW) { lines.push(line); line = ch; } else line += ch;
      if (lines.length >= maxLines) break; }
    if (line && lines.length < maxLines) lines.push(line);
    lines.forEach(function (l, i) { x.fillText(l, cx, y + i * lh); });
    return y + lines.length * lh;
  }
  function drawHexCard(h, dong, yaoText, baihua, tag) {
    var c = document.createElement("canvas"); c.width = 1080; c.height = 1440;
    var x = c.getContext("2d");
    var g = x.createLinearGradient(0, 0, 0, 1440);
    g.addColorStop(0, "#161c26"); g.addColorStop(1, "#0b0e13");
    x.fillStyle = g; x.fillRect(0, 0, 1080, 1440);
    x.strokeStyle = "rgba(201,160,80,.6)"; x.lineWidth = 3; x.strokeRect(30, 30, 1020, 1380);
    x.strokeStyle = "rgba(127,184,168,.3)"; x.lineWidth = 1.5; x.strokeRect(46, 46, 988, 1348);
    x.textAlign = "center";
    x.fillStyle = "#c9a050"; x.font = '26px "Songti SC","STSong",serif';
    x.fillText("易 经 口 袋", 540, 118);
    x.fillStyle = "#8d94a1"; x.font = '20px serif';
    x.fillText(tag || "", 540, 160);
    guaDrawCard(x, h.lines_top_down.slice().reverse(), dong, 540, 208, 280);
    x.fillStyle = "#e6e1d3"; x.font = '900 84px "Songti SC","STSong",serif';
    x.fillText("第" + h.index + "卦 · " + h.title, 540, 742);
    x.fillStyle = "#7fb8a8"; x.font = '30px "Songti SC",serif';
    x.fillText(h.eyebrow, 540, 802);
    x.fillStyle = "#e6c37f"; x.font = '34px "Songti SC",serif';
    var y = wrap(x, yaoText || h.guaci, 540, 872, 880, 50, 3);
    x.fillStyle = "#b9b3a3"; x.font = '26px "Songti SC",serif';
    y = wrap(x, baihua || h.guaci_baihua, 540, y + 24, 880, 40, 4);
    x.strokeStyle = "rgba(201,160,80,.4)"; x.beginPath(); x.moveTo(330, 1286); x.lineTo(750, 1286); x.stroke();
    x.fillStyle = "#8d94a1"; x.font = '21px "Songti SC",serif';
    x.fillText("AI PASSPORT · 易经口袋 · 传统文化娱乐参考", 540, 1334);
    x.fillText("在▁▁搜索「易经口袋」同款小工具", 540, 1372);
    return c.toDataURL("image/png");
  }
  /* ---------- 收藏 ---------- */
  var favs = {};
  AAPT.getJSON("yj_favs", {}, function (o) { favs = o || {}; refreshFavBtn(currentGua); });
  function refreshFavBtn(i) {
    var b = viewEl.querySelector('button[data-x="fav"][data-i="' + i + '"]');
    if (b) b.textContent = favs["g" + i] ? "★ 已收藏" : "☆ 收 藏";
  }
  var currentGua = 0;

  /* ---------- 路由 ---------- */
  var VIEWS = { pan: renderPan, cast: renderCast, about: renderAbout };
  function setView(v) {
    document.querySelectorAll(".tabs button").forEach(function (b) {
      b.classList.toggle("on", b.getAttribute("data-v") === v);
    });
    (VIEWS[v] || renderPan)();
  }
  document.querySelector(".tabs").addEventListener("click", function (ev) {
    var b = ev.target && ev.target.closest && ev.target.closest("button[data-v]");
    if (!b) return;
    AAPT.buzz(8);
    setView(b.getAttribute("data-v"));
  });
  viewEl.addEventListener("click", function (ev) {
    var t = ev.target;
    var cell = t.closest && t.closest(".hex-cell");
    if (cell) { AAPT.buzz(8); currentGua = parseInt(cell.getAttribute("data-idx")); renderGua(currentGua); return; }
    var f = t.closest && t.closest(".filters button");
    if (f) {
      state.filterSec = f.getAttribute("data-f");
      viewEl.querySelectorAll(".filters button").forEach(function (b) { b.classList.toggle("on", b === f); });
      var grid = viewEl.querySelector(".grid"); if (!grid) return;
      var cells = grid.querySelectorAll(".hex-cell");
      for (var i = 0; i < cells.length; i++) {
        var idx = parseInt(cells[i].getAttribute("data-idx"));
        var show = state.filterSec === "all" || (state.filterSec === "up" ? idx <= 30 : idx > 30);
        cells[i].style.display = show ? "" : "none";
      }
      return;
    }
    var xb = t.closest && t.closest(".actions button");
    if (xb) {
      var op = xb.getAttribute("data-x");
      AAPT.buzz(10);
      if (op === "fav") {
        var i = parseInt(xb.getAttribute("data-i")), k = "g" + i;
        if (favs[k]) delete favs[k]; else favs[k] = Date.now();
        AAPT.setJSON("yj_favs", favs, function () {
          AAPT.toast(favs[k] ? "已收藏" : "已取消收藏");
          refreshFavBtn(i);
        });
      } else if (op === "save") {
        var i2 = parseInt(xb.getAttribute("data-i")), h2 = hexByIdx(i2);
        AAPT.saveImage(drawHexCard(h2, 0, h2.guaci, h2.guaci_baihua, h2.eyebrow), "签卡已存入相册");
      } else if (op === "post") {
        var i3 = parseInt(xb.getAttribute("data-i")), h3 = hexByIdx(i3);
        AAPT.postNote({
          title: ("易经口袋 · " + h3.title).slice(0, 20),
          content: "翻开《周易》第" + h3.index + "卦「" + h3.title + "」。" + h3.guaci + " " + h3.guaci_baihua + "（传统文化娱乐参考）",
          image: drawHexCard(h3, 0, h3.guaci, h3.guaci_baihua, h3.eyebrow)
        });
      } else if (op === "csave" && state.lastCast) {
        var lc = state.lastCast, dy = lc.dong ? lc.ben.yaos[lc.dong - 1] : null;
        AAPT.saveImage(drawHexCard(lc.ben, lc.dong, dy ? dy.text : lc.ben.guaci, dy ? dy.baihua : lc.ben.guaci_baihua, lc.tag), "签卡已存入相册");
      } else if (op === "cpost" && state.lastCast) {
        var lc2 = state.lastCast, dy2 = lc2.dong ? lc2.ben.yaos[lc2.dong - 1] : null;
        AAPT.postNote({
          title: ("起得一卦 · " + lc2.ben.title).slice(0, 20),
          content: lc2.tag + "，得第" + lc2.ben.index + "卦「" + lc2.ben.title + "」。" + (dy2 ? dy2.text : lc2.ben.guaci) + "（梅花易数 · 传统文化娱乐参考）",
          image: drawHexCard(lc2.ben, lc2.dong, dy2 ? dy2.text : lc2.ben.guaci, dy2 ? dy2.baihua : lc2.ben.guaci_baihua, lc2.tag)
        });
      }
    }
  });
  /* 铜钱动爻记录：改写 coins 逻辑中缺失的一环 —— 在 renderCast 的 toss 里保存 moving 索引 */
  var _renderCast = renderCast;
  renderCast = function () {
    _renderCast();
    window.__movingIdx = 0;
    var coins = document.getElementById("coins");
    if (coins) coins.addEventListener("click", function () {
      /* 与内部 tossed 逻辑同步：记录最新一爻是否动 —— 通过 DOM 最后一行的标记读取 */
      var rows = document.querySelectorAll("#tossed .yaorow");
      if (rows.length) {
        var last = rows[rows.length - 1];
        window.__movingIdx = last.textContent.indexOf("动爻") >= 0 ? rows.length : window.__movingIdx;
      }
    });
  };

  setView("pan");
})();
