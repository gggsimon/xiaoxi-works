(function(){
"use strict";
/* ================= 数据 ================= */
var KEY="mw_entries";
var entries={};   /* {dateKey:{w,e,n,ts}} */
var wx="sun",eng=3;
var WX_NAME={sun:"晴",cloud:"多云",rain:"雨",storm:"雷",fog:"雾",snow:"雪"};
var WX_GLYPH={sun:"☀",cloud:"☁",rain:"🌧",storm:"⛈",fog:"🌫",snow:"❄"};
var WX_SKY={
  sun:  [["#f6d9a8","#e8b764"],["#fbeed3","#f0cf9a"]],
  cloud:[["#c3cdd6","#9aa8b5"],["#dfe5ea","#bcc8d2"]],
  rain: [["#8fa3b5","#6b93ad"],["#b9c8d4","#8fa3b5"]],
  storm:[["#6d7885","#4d5866"],["#8b96a2","#66727e"]],
  fog:  [["#d4d8d2","#b9bfb4"],["#e8eae4","#ccd2c9"]],
  snow: [["#c9d6de","#a9bcc9"],["#e4ecf1","#c5d3dd"]]
};
var ENG_TXT=["","很低","偏低","一般","不错","充沛"];

function dkey(d){return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2);}
function today(){return dkey(new Date());}
/* 小工具容器：数据走平台 Storage（aapt 内部版本门控 + localStorage 兜底双写） */
function load(cb){AAPT.getJSON(KEY,{},function(v){entries=v||{};if(cb)cb();});}
function save(){AAPT.setJSON(KEY,entries);}
function seeded(s){var h=0;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return function(){h=(h*1103515245+12345)&0x7fffffff;return h/0x7fffffff;};}

/* ================= 场景绘制 ================= */
var sceneCv=document.getElementById("scene"),sx=sceneCv.getContext("2d");
function drawScene(cv,cx,W,H,w,e,note,seedStr){
  var rnd=seeded(seedStr);
  var pal=WX_SKY[w];
  var g=cx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,pal[0][0]);g.addColorStop(1,pal[0][1]);
  cx.fillStyle=g;cx.fillRect(0,0,W,H);
  /* 远景地形剪影 */
  cx.fillStyle="rgba(40,48,44,.16)";
  cx.beginPath();cx.moveTo(0,H);
  for(var i=0;i<=W;i+=40){
    var y=H*0.72+Math.sin(i*0.013+rnd()*2)*H*0.05+Math.sin(i*0.041)*H*0.02;
    cx.lineTo(i,y);
  }
  cx.lineTo(W,H);cx.closePath();cx.fill();
  /* 地面 */
  var g2=cx.createLinearGradient(0,H*0.78,0,H);
  g2.addColorStop(0,"rgba(40,48,44,.10)");g2.addColorStop(1,"rgba(40,48,44,.26)");
  cx.fillStyle=g2;cx.fillRect(0,H*0.78,W,H*0.22);

  if(w==="sun"){
    var sxp=W*0.76,syp=H*0.24;
    var sg=cx.createRadialGradient(sxp,syp,4,sxp,syp,H*0.42);
    sg.addColorStop(0,"rgba(255,246,220,.95)");sg.addColorStop(0.25,"rgba(255,236,190,.55)");sg.addColorStop(1,"rgba(255,236,190,0)");
    cx.fillStyle=sg;cx.fillRect(0,0,W,H);
    cx.fillStyle="#fff3d8";cx.beginPath();cx.arc(sxp,syp,H*0.075,0,6.283);cx.fill();
    for(var r2=0;r2<12;r2++){
      var a=r2/12*6.283+rnd()*0.3;
      cx.strokeStyle="rgba(255,244,214,"+(0.25+rnd()*0.2)+")";cx.lineWidth=2;
      cx.beginPath();cx.moveTo(sxp+Math.cos(a)*H*0.1,syp+Math.sin(a)*H*0.1);
      cx.lineTo(sxp+Math.cos(a)*H*0.16,syp+Math.sin(a)*H*0.16);cx.stroke();
    }
  }
  if(w==="cloud"||w==="storm"||w==="rain"){
    for(var c=0;c<5;c++){
      var cxp=rnd()*W,cyp=H*(0.1+rnd()*0.3),cs=H*(0.08+rnd()*0.09);
      cx.fillStyle=w==="storm"?"rgba(60,68,78,.5)":"rgba(255,255,255,.5)";
      cx.beginPath();
      cx.arc(cxp,cyp,cs,0,6.283);cx.arc(cxp+cs*0.9,cyp+cs*0.1,cs*0.75,0,6.283);
      cx.arc(cxp-cs*0.9,cyp+cs*0.15,cs*0.68,0,6.283);cx.fill();
    }
  }
  if(w==="rain"||w==="storm"){
    cx.strokeStyle="rgba(220,232,240,.55)";cx.lineWidth=1.4;
    for(var d2=0;d2<90;d2++){
      var rx2=rnd()*W,ry2=rnd()*H,rl=8+rnd()*12;
      cx.beginPath();cx.moveTo(rx2,ry2);cx.lineTo(rx2-2,ry2+rl);cx.stroke();
    }
    if(w==="storm"){
      cx.strokeStyle="rgba(255,244,214,"+(0.5+rnd()*0.5)+")";cx.lineWidth=3;
      cx.beginPath();cx.moveTo(W*0.62,H*0.1);cx.lineTo(W*0.54,H*0.3);cx.lineTo(W*0.6,H*0.3);cx.lineTo(W*0.5,H*0.52);cx.stroke();
    }
  }
  if(w==="fog"){
    for(var f=0;f<7;f++){
      var fxp=rnd()*W,fyp=H*(0.35+rnd()*0.55),fs=H*(0.1+rnd()*0.12);
      var fg=cx.createRadialGradient(fxp,fyp,0,fxp,fyp,fs);
      fg.addColorStop(0,"rgba(255,255,255,.32)");fg.addColorStop(1,"rgba(255,255,255,0)");
      cx.fillStyle=fg;cx.beginPath();cx.arc(fxp,fyp,fs,0,6.283);cx.fill();
    }
  }
  if(w==="snow"){
    cx.fillStyle="rgba(255,255,255,.85)";
    for(var s2=0;s2<70;s2++){
      var spx=rnd()*W,spy=rnd()*H,ss=1+rnd()*2.4;
      cx.globalAlpha=0.4+rnd()*0.6;
      cx.beginPath();cx.arc(spx,spy,ss,0,6.283);cx.fill();
    }
    cx.globalAlpha=1;
  }
  /* 能量：地平线上的光带 */
  var eg=cx.createLinearGradient(0,H*0.8,0,H);
  eg.addColorStop(0,"rgba(255,255,255,0)");
  eg.addColorStop(1,"rgba(255,255,255,"+(0.05+e*0.055)+")");
  cx.fillStyle=eg;cx.fillRect(0,H*0.8,W,H*0.2);
  /* 日期与天气 */
  cx.fillStyle="rgba(255,255,255,.92)";
  cx.font='700 '+Math.round(H*0.052)+'px "Noto Serif SC","Songti SC",serif';
  cx.textAlign="left";
  cx.fillText(WX_NAME[w]+" · "+ENG_TXT[e],W*0.06,H*0.14);
  if(note){
    cx.font='400 '+Math.round(H*0.036)+'px "Noto Serif SC","Songti SC",serif';
    cx.fillStyle="rgba(255,255,255,.85)";
    var words=note.slice(0,26);
    cx.fillText(words,W*0.06,H*0.14+H*0.075);
  }
}
function refreshScene(){
  drawScene(sceneCv,sx,600,380,wx,eng,"","cur-"+wx+"-"+eng);
}

/* ================= 今天 ================= */
var wxBox=document.getElementById("wx");
wxBox.addEventListener("click",function(ev){
  var b=ev.target.closest("button[data-w]");if(!b)return;
  wx=b.getAttribute("data-w");
  var bs=wxBox.querySelectorAll("button");
  for(var i=0;i<bs.length;i++)bs[i].className=bs[i]===b?"on":"";
  buzz(8);refreshScene();
});
var segBox=document.getElementById("seg");
segBox.addEventListener("click",function(ev){
  var b=ev.target.closest("button[data-e]");if(!b)return;
  eng=parseInt(b.getAttribute("data-e"),10);
  var bs=segBox.querySelectorAll("button");
  for(var i=0;i<bs.length;i++)bs[i].className=bs[i]===b?"on":"";
  document.getElementById("engTxt").textContent=ENG_TXT[eng];
  buzz(6);refreshScene();
});
function buzz(ms){try{if(navigator.vibrate)navigator.vibrate(ms);}catch(e){}}

var btnRec=document.getElementById("btnRec");
btnRec.addEventListener("click",function(){
  var k=today();
  var existed=!!entries[k];
  entries[k]={w:wx,e:eng,n:document.getElementById("note").value.trim(),ts:Date.now()};
  save();
  btnRec.textContent=existed?"已 更 新 今 天":"记 录 成 功";
  btnRec.classList.add("done");
  buzz([12,30,12]);
  setTimeout(function(){btnRec.textContent="记 下 今 天";btnRec.classList.remove("done");},1800);
  renderHis();renderCal();
});
/* 回填今天 */
(function(){
  var k=today(),t=entries[k];
  if(t){
    wx=t.w;eng=t.e;document.getElementById("note").value=t.n||"";
    var bs=wxBox.querySelectorAll("button");
    for(var i=0;i<bs.length;i++)bs[i].className=bs[i].getAttribute("data-w")===wx?"on":"";
    var bs2=segBox.querySelectorAll("button");
    for(var j=0;j<bs2.length;j++)bs2[j].className=parseInt(bs2[j].getAttribute("data-e"),10)===eng?"on":"";
    document.getElementById("engTxt").textContent=ENG_TXT[eng];
  }
})();

/* ================= 历史 ================= */
function renderHis(){
  var keys=Object.keys(entries).sort().reverse().slice(0,10);
  var box=document.getElementById("his");
  document.getElementById("hisEmpty").style.display=keys.length?"none":"block";
  var h="";
  keys.forEach(function(k){
    var t=entries[k];
    h+='<div class="hrow"><canvas width="104" height="136" data-k="'+k+'"></canvas>'+
       '<div class="meta"><b>'+k.slice(5).replace("-","月")+'日 · '+WX_NAME[t.w]+'</b>'+
       '<div>能量 '+ENG_TXT[t.e]+(t.n?" · "+esc(t.n):"")+'</div></div>'+
       '<span class="e">'+WX_GLYPH[t.w]+'</span></div>';
  });
  box.innerHTML=h;
  var cvs=box.querySelectorAll("canvas");
  for(var i=0;i<cvs.length;i++){
    (function(cv2){
      var k2=cv2.getAttribute("data-k"),t2=entries[k2];
      drawScene(cv2,cv2.getContext("2d"),104,136,t2.w,t2.e,t2.n,k2);
    })(cvs[i]);
  }
}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;");}

/* ================= 日历 ================= */
var calY,calM;
(function(){var d=new Date();calY=d.getFullYear();calM=d.getMonth();})();
var selDay=null;
function renderCal(){
  document.getElementById("cmTxt").textContent=calY+" 年 "+(calM+1)+" 月";
  var first=new Date(calY,calM,1).getDay();
  var days=new Date(calY,calM+1,0).getDate();
  var h="";
  var wds=["日","一","二","三","四","五","六"];
  for(var w=0;w<7;w++)h+='<div class="wd">'+wds[w]+'</div>';
  for(var e=0;e<first;e++)h+='<div class="cell blank"></div>';
  var cnt=0,sunC=0,rainC=0,sumE=0;
  for(var d=1;d<=days;d++){
    var k=calY+"-"+("0"+(calM+1)).slice(-2)+"-"+("0"+d).slice(-2);
    var t=entries[k];
    var cls="cell";
    if(t){
      cls+=" have";cnt++;
      if(t.w==="sun")sunC++;
      if(t.w==="rain"||t.w==="storm")rainC++;
      sumE+=t.e;
    }
    if(k===today())cls+=" today";
    if(k===selDay)cls+=" sel";
    h+='<div class="'+cls+'" data-k="'+k+'"><span class="d">'+d+'</span>'+(t?'<span class="g">'+WX_GLYPH[t.w]+'</span>':"")+'</div>';
  }
  document.getElementById("grid").innerHTML=h;
  document.getElementById("calStats").innerHTML=
    '<div><b>'+cnt+'</b><em>记录天数</em></div>'+
    '<div><b>'+(cnt?sunC:0)+'</b><em>晴天</em></div>'+
    '<div><b>'+(cnt?rainC:0)+'</b><em>雨天</em></div>'+
    '<div><b>'+(cnt?(sumE/cnt).toFixed(1):"—")+'</b><em>平均能量</em></div>';
  if(selDay)renderDay();
}
document.getElementById("grid").addEventListener("click",function(ev){
  var c=ev.target.closest(".cell[data-k]");if(!c)return;
  selDay=c.getAttribute("data-k");
  buzz(8);renderCal();
});
function renderDay(){
  var t=entries[selDay];
  var box=document.getElementById("dayDetail");
  document.getElementById("dayTxt").textContent=selDay.replace("-","年").replace("-","月")+"日";
  if(!t){box.innerHTML='<div class="empty">这天没有记录。</div>';return;}
  box.innerHTML='<div class="hrow" style="border:0"><canvas width="104" height="136" id="dayCv"></canvas>'+
    '<div class="meta"><b>'+WX_NAME[t.w]+' · 能量 '+ENG_TXT[t.e]+'</b>'+
    '<div>'+(t.n?esc(t.n):"（没有留言）")+'</div></div><span class="e">'+WX_GLYPH[t.w]+'</span></div>';
  var cv2=document.getElementById("dayCv");
  drawScene(cv2,cv2.getContext("2d"),104,136,t.w,t.e,t.n,selDay);
}
document.getElementById("prevM").addEventListener("click",function(){calM--;if(calM<0){calM=11;calY--;}buzz(6);renderCal();});
document.getElementById("nextM").addEventListener("click",function(){calM++;if(calM>11){calM=0;calY++;}buzz(6);renderCal();});

/* ================= 月报 ================= */
var monthly={n:0,avg:0,cnt:0,sunC:0,rainC:0,keys:[]};
function renderReport(){
  var cv2=document.getElementById("repCv"),cx=cv2.getContext("2d");
  var W=cv2.width,H=cv2.height;
  var keys=Object.keys(entries).filter(function(k){return k.indexOf(calY+"-"+("0"+(calM+1)).slice(-2))===0;}).sort();
  var g=cx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,"#f4f7f3");g.addColorStop(1,"#e7ede8");
  cx.fillStyle=g;cx.fillRect(0,0,W,H);
  cx.strokeStyle="rgba(94,140,123,.4)";cx.lineWidth=3;cx.strokeRect(28,28,W-56,H-56);
  cx.textAlign="center";
  cx.fillStyle="#5e8c7b";cx.font='400 26px "Noto Serif SC",serif';
  cx.fillText("心 事 气 象 台 · 天 气 月 报",W/2,110);
  cx.fillStyle="#33372f";cx.font='900 72px "Noto Serif SC",serif';
  cx.fillText(calY+"年"+(calM+1)+"月",W/2,205);
  cx.fillStyle="#8b9484";cx.font='400 26px "Noto Serif SC",serif';
  cx.fillText("本月记录 "+keys.length+" 天",W/2,255);
  /* 天气分布圆点阵 */
  var counts={},sumE=0;
  keys.forEach(function(k){counts[entries[k].w]=(counts[entries[k].w]||0)+1;sumE+=entries[k].e;});
  var order=["sun","cloud","rain","storm","fog","snow"];
  var bx=W*0.5-(order.length*64)/2,by=320;
  order.forEach(function(w2,i){
    var n=counts[w2]||0;
    var px=bx+i*64+32;
    cx.fillStyle=n?"rgba(94,140,123,.12)":"rgba(51,55,47,.05)";
    cx.beginPath();cx.arc(px,by,30,0,6.283);cx.fill();
    cx.fillStyle=n?"#476f62":"#b6bdb1";
    cx.font='700 34px sans-serif';cx.fillText(WX_GLYPH[w2],px,by+12);
    cx.font='400 22px "Noto Serif SC",serif';
    cx.fillText(WX_NAME[w2],px,by+62);
    cx.fillStyle="#476f62";cx.font='700 30px "Noto Serif SC",serif';
    cx.fillText(n+" 天",px,by+100);
  });
  /* 能量曲线 */
  if(keys.length){
    var lx=110,lw=W-220,ly=H*0.52,lh=H*0.2;
    cx.strokeStyle="rgba(51,55,47,.15)";cx.lineWidth=2;
    cx.beginPath();cx.moveTo(lx,ly);cx.lineTo(lx+lw,ly);cx.stroke();
    cx.strokeStyle="rgba(94,140,123,.8)";cx.lineWidth=3;cx.beginPath();
    keys.forEach(function(k,i){
      var px2=lx+(keys.length===1?lw/2:i/(keys.length-1)*lw);
      var py2=ly+lh-(entries[k].e-1)/4*lh;
      if(i===0)cx.moveTo(px2,py2);else cx.lineTo(px2,py2);
    });
    cx.stroke();
    keys.forEach(function(k,i){
      var px2=lx+(keys.length===1?lw/2:i/(keys.length-1)*lw);
      var py2=ly+lh-(entries[k].e-1)/4*lh;
      cx.fillStyle="#476f62";cx.beginPath();cx.arc(px2,py2,6,0,6.283);cx.fill();
    });
    cx.fillStyle="#8b9484";cx.font='400 22px "Noto Serif SC",serif';
    cx.fillText("能量走势 · 平均 "+(sumE/keys.length).toFixed(1),W/2,ly+lh+50);
  }
  /* 结语 */
  var avg=keys.length?sumE/keys.length:0;
  monthly={n:keys.length,avg:avg,sunC:(counts.sun||0),rainC:((counts.rain||0)+(counts.storm||0)),keys:keys};
  var word=avg>=4?"这个月大部分时间，天是亮的。":avg>=3?"这个月不坏，有晴有雨，都过去了。":avg>=2?"这个月偏雨。记得晒自己。":"这个月很难。但你都记下来了，这很勇敢。";
  cx.fillStyle="#33372f";cx.font='400 34px "Noto Serif SC",serif';
  cx.fillText(word,W/2,H*0.82);
  cx.fillStyle="#8b9484";cx.font='400 22px "Noto Serif SC",serif';
  cx.fillText("心事气象台 · 天气心里雨 · 本地记录",W/2,H-70);
}
document.getElementById("btnSaveRep").addEventListener("click",function(){
  buzz(12);
  AAPT.saveImage(document.getElementById("repCv").toDataURL("image/png"),"月报已存入相册");
});
document.getElementById("btnPost").addEventListener("click",function(){
  buzz(10);
  var m=monthly;
  var title=(calY+"年"+(calM+1)+"月心事气象公报").slice(0,20);
  var txt="这个月记了 "+m.n+" 天";
  if(m.n){
    txt+="，平均能量 "+m.avg.toFixed(1)+" / 5";
    if(m.sunC)txt+="，晴 "+m.sunC+" 天";
    if(m.rainC)txt+="，雨天 "+m.rainC+" 天";
  }
  txt+="。\n\n心情不用翻译，记下来就是天气。\n#心事气象台";
  AAPT.postNote({title:title,content:txt,image:document.getElementById("repCv").toDataURL("image/png")});
});
document.querySelector(".tabs").addEventListener("click",function(ev){
  var b=ev.target.closest("button[data-t]");if(!b)return;
  var bs=document.querySelectorAll(".tabs button");
  for(var i=0;i<bs.length;i++)bs[i].className=bs[i]===b?"on":"";
  var ids=["now","cal","rep"];
  for(var j=0;j<ids.length;j++)document.getElementById("pane-"+ids[j]).className="pane"+(ids[j]===b.getAttribute("data-t")?" on":"");
  buzz(6);
  if(b.getAttribute("data-t")==="rep")renderReport();
});

/* ================= 启动 ================= */
var d=new Date();
document.getElementById("today").textContent=(d.getMonth()+1)+"月"+d.getDate()+"日";
load(function(){
  refreshScene();renderHis();renderCal();
});
})();
