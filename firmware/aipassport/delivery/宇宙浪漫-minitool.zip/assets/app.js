/* 宇宙浪漫：落入爱的黑洞 · 移动端原生版
 * 还原固件核心：开放宇宙巡航 / 计算星云 / 四套配色轮换 / 分形星域 / 跃迁白闪
 *   / 爱的黑洞（引力井·光子环·星尘指路·REBORN）/ 深空低频声 / 五连击彩蛋
 * 移动端新增：触控油门与转向、战绩持久化、结果卡存图/发笔记、彩蛋解锁图鉴
 */
(function () {
  "use strict";
  var A = window.AAPT;
  var cv = document.getElementById("cv");
  var g = cv.getContext("2d");
  var W = 0, H = 0, DPR = 1, CX = 0, CY = 0, FOC = 0;

  /* ---------------- 配色 ---------------- */
  var PALS = [
    { name: "紫罗兰之海", bg0: "#120b26", bg1: "#07060f", n1: "#7c4dff", n2: "#b388ff", n3: "#3f2d7a", star: "#f2eeff", ring: "#ffb35c" },
    { name: "深空蓝渊",   bg0: "#081428", bg1: "#050b14", n1: "#2d6cdf", n2: "#7fb2ff", n3: "#173a6b", star: "#eaf4ff", ring: "#9fd0ff" },
    { name: "超新星墓场", bg0: "#1c0d08", bg1: "#0d0605", n1: "#ff7043", n2: "#ffc9a3", n3: "#7a2e1a", star: "#fff3e6", ring: "#ffd54f" },
    { name: "翡翠原野",   bg0: "#07170f", bg1: "#040d09", n1: "#26a69a", n2: "#a5f0dd", n3: "#0f4a40", star: "#eafff6", ring: "#b2ffcc" },
    { name: "玫瑰之心",   bg0: "#1d0a14", bg1: "#0d050a", n1: "#ff5c8a", n2: "#ffb3c9", n3: "#6e1f3d", star: "#fff0f5", ring: "#ffe0eb", egg: true }
  ];
  var FRACTAL_NAMES = ["分形回廊", "折叠星域", "无穷阶梯"];

  var pal = PALS[0], fractal = false, uniNo = 1;
  var hole = { x: 0, y: 0, z: 110 };
  var STATS = { j: 0, r: 0, c: null, e: 0 };

  /* ---------------- 运行状态 ---------------- */
  var running = false, rafId = 0, lastT = 0, T = 0;
  var v = 4.5, throttle = false, steer = 0, steerT = 0, panX = 0;
  var dist = 999, pullK = 0;
  var white = false, rebornBusy = false;
  var sndOn = false, actx = null, osc1 = null, osc2 = null, agn = null;
  var tapTimes = [];

  /* ---------------- 星空 ---------------- */
  var stars = [];
  function initStars() {
    stars = [];
    for (var i = 0; i < 230; i++) { stars.push(newStar(2 + Math.random() * 88)); }
  }
  function newStar(z) {
    return {
      x: (Math.random() * 2 - 1) * 26,
      y: (Math.random() * 2 - 1) * 17,
      z: z,
      b: 0.35 + Math.random() * 0.65,
      tw: Math.random() * 6.28,
      big: Math.random() < 0.055
    };
  }

  /* ---------------- 发光贴图 ---------------- */
  function makeGlow(color, inner) {
    var c = document.createElement("canvas"); c.width = 128; c.height = 128;
    var x = c.getContext("2d");
    var gd = x.createRadialGradient(64, 64, 2, 64, 64, 62);
    gd.addColorStop(0, inner || color);
    gd.addColorStop(0.35, color);
    gd.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = gd; x.fillRect(0, 0, 128, 128);
    return c;
  }
  var glowCache = {};
  function glow(key, color, inner) {
    if (!glowCache[key]) { glowCache[key] = makeGlow(color, inner); }
    return glowCache[key];
  }
  function blobFor(pi, ci) {
    var k = "b" + pi + "_" + ci;
    if (!glowCache[k]) {
      var p = PALS[pi];
      var col = ci === 0 ? p.n1 : (ci === 1 ? p.n2 : p.n3);
      var inner = ci === 1 ? rgba(col, 0.9) : rgba(col, 0.55);
      glowCache[k] = makeGlow(rgba(col, 0.5), inner);
    }
    return glowCache[k];
  }
  function rgba(hex, a) {
    var r = parseInt(hex.slice(1, 3), 16), gg = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return "rgba(" + r + "," + gg + "," + b + "," + a + ")";
  }

  /* ---------------- 分形星域 ---------------- */
  var fPts = [];
  function genFractal() {
    fPts = [];
    (function rec(px, py, ang, len, depth) {
      if (depth <= 0 || len < 0.012) { return; }
      var nx = px + Math.cos(ang) * len, ny = py + Math.sin(ang) * len;
      fPts.push({ x: nx, y: ny, d: depth, tw: Math.random() * 6.28 });
      for (var s = -1; s <= 1; s++) {
        fPts.push({ x: nx + (Math.random() - 0.5) * len * 0.7, y: ny + (Math.random() - 0.5) * len * 0.7, d: depth, tw: Math.random() * 6.28 });
      }
      var n = depth > 4 ? 2 : 3;
      for (var i = 0; i < n; i++) {
        rec(nx, ny, ang + (i - (n - 1) / 2) * 0.6 + (Math.random() - 0.5) * 0.22, len * 0.6, depth - 1);
      }
    })(0, 0.52, -Math.PI / 2, 0.42, 6);
  }

  /* ---------------- 宇宙生成 ---------------- */
  function palPool() {
    var arr = [0, 1, 2, 3];
    if (STATS.e) { arr.push(4); }
    return arr;
  }
  function newUniverse(forcePal, forceFrac) {
    var pool = palPool();
    var pi;
    if (forcePal != null) { pi = forcePal; }
    else { do { pi = pool[Math.floor(Math.random() * pool.length)]; } while (pool.length > 1 && pi === palIdx()); }
    pal = PALS[pi];
    fractal = forceFrac != null ? !!forceFrac : (Math.random() < 0.25);
    hole.x = (Math.random() * 2 - 1) * 9;
    hole.y = (Math.random() * 2 - 1) * 5;
    hole.z = 95 + Math.random() * 55;
    dist = Math.sqrt(hole.x * hole.x + hole.y * hole.y + hole.z * hole.z);
    v = 4.5;
    var nm = fractal ? FRACTAL_NAMES[Math.floor(Math.random() * FRACTAL_NAMES.length)] : pal.name;
    document.getElementById("uName").textContent = "第 " + uniNo + " 宇宙 · " + nm;
  }
  function palIdx() {
    for (var i = 0; i < PALS.length; i++) { if (PALS[i] === pal) { return i; } }
    return 0;
  }

  /* ---------------- 主循环 ---------------- */
  function loop(t) {
    rafId = requestAnimationFrame(loop);
    if (!lastT) { lastT = t; }
    var dt = (t - lastT) / 1000; lastT = t;
    if (dt > 0.08) { dt = 0.08; }
    T += dt;
    step(dt);
    render();
  }
  function step(dt) {
    var vT = throttle ? 27 : 4.5;
    v += (vT - v) * Math.min(1, dt * 2.4);
    steer += (steerT - steer) * Math.min(1, dt * 3.2);
    panX = steer * 7;

    hole.z -= v * dt;
    if (!rebornBusy) {
      dist = Math.sqrt(hole.x * hole.x + hole.y * hole.y + hole.z * hole.z);
      if (dist < (STATS.c == null ? 1e9 : STATS.c)) { STATS.c = Math.round(dist * 10) / 10; saveStats(); }
      if (dist < 30) {
        pullK = Math.min(1, (30 - dist) / 27);
        hole.z -= pullK * 13 * dt;
        hole.x -= hole.x * pullK * 1.1 * dt;
        hole.y -= hole.y * pullK * 1.1 * dt;
        dist = Math.sqrt(hole.x * hole.x + hole.y * hole.y + hole.z * hole.z);
        if (dist < 3.0) { doReborn(); }
      } else { pullK = 0; }
    }
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      s.z -= v * dt * (s.big ? 1.15 : 1);
      if (s.z < 2) {
        var ns = newStar(88 + Math.random() * 4);
        stars[i] = ns;
      }
    }
    if (sndOn) { updateDrone(); }
    var el = document.getElementById("uDist");
    if (el) { el.textContent = rebornBusy ? "—" : Math.max(0, Math.round(dist)); }
  }

  function proj(x, y, z) {
    var k = FOC / z;
    return { sx: CX + (x - panX) * k, sy: CY + y * k, k: k };
  }
  function holeScreen() {
    if (hole.z < 1.2) { return null; }
    var p = proj(hole.x, hole.y, hole.z);
    if (p.sx < -W || p.sx > W * 2 || p.sy < -H || p.sy > H * 2) { return null; }
    return p;
  }

  function render() {
    g.globalCompositeOperation = "source-over";
    var bg = g.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, pal.bg0); bg.addColorStop(1, pal.bg1);
    g.fillStyle = bg; g.fillRect(0, 0, W, H);

    var hp = holeScreen();
    var prox = hp ? Math.max(0, 1 - dist / 55) : 0;

    /* 星云 / 分形 */
    if (fractal) { drawFractal(); }
    else { drawNebula(hp, prox); }

    /* 星 */
    drawStars(hp);

    /* 黑洞 */
    if (hp) { drawHole(hp, prox); }

    /* 星尘指路 */
    if (hp && dist > 4) { drawDust(hp); }
  }

  function drawNebula(hp, prox) {
    g.globalCompositeOperation = "screen";
    var pi = palIdx();
    var defs = [
      { s: blobFor(pi, 0), x: 0.24, y: 0.30, sz: 1.5, a: 0.5, sp: 0.05 },
      { s: blobFor(pi, 1), x: 0.74, y: 0.62, sz: 1.15, a: 0.34, sp: 0.037 },
      { s: blobFor(pi, 2), x: 0.52, y: 0.16, sz: 0.95, a: 0.30, sp: 0.062 }
    ];
    for (var i = 0; i < defs.length; i++) {
      var d = defs[i];
      var bx = (d.x + Math.sin(T * d.sp + i * 2.1) * 0.05) * W;
      var by = (d.y + Math.cos(T * d.sp * 0.8 + i) * 0.05) * H;
      if (hp) { bx += (hp.sx - CX) * prox * 0.30; by += (hp.sy - CY) * prox * 0.30; }
      var sz = d.sz * H * (1 + prox * 0.22);
      g.globalAlpha = d.a;
      g.drawImage(d.s, bx - sz / 2, by - sz / 2, sz, sz);
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = "source-over";
  }

  function drawFractal() {
    var pi = palIdx();
    var colStar = pal.star, colNeb = pal.n2;
    var sc = Math.min(W, H) * 0.92;
    var rot = T * 0.07;
    var c1 = Math.cos(rot), s1 = Math.sin(rot);
    var cxc = W / 2, cyc = H * 0.44;
    var tcount = fPts.length;
    for (var i = 0; i < tcount; i += 1) {
      var p = fPts[i];
      var fold = Math.sin(T * 0.32 + p.d * 0.85) * 0.10 * (1 + Math.abs(p.x) * 1.6);
      var ca = Math.cos(fold), sa = Math.sin(fold);
      var fx = p.x * ca - p.y * sa;
      var fy = p.x * sa + p.y * ca;
      var rx = fx * c1 - fy * s1;
      var ry = fx * s1 + fy * c1;
      var sx = cxc + rx * sc, sy = cyc + ry * sc;
      if (sx < -8 || sx > W + 8 || sy < -8 || sy > H + 8) { continue; }
      var tw = 0.45 + 0.55 * Math.sin(T * 2 + p.tw);
      g.globalAlpha = 0.14 + 0.5 * tw;
      g.fillStyle = (i % 7 === 0) ? colNeb : colStar;
      var r = (p.d > 4 ? 1.6 : 1.1) * (0.7 + 0.3 * tw) * DPR > 2 ? 1.6 : 1.3;
      g.fillRect(sx, sy, r, r);
    }
    g.globalAlpha = 1;
  }

  function drawStars(hp) {
    var core = null;
    if (hp) {
      var coreR = Math.max(3, Math.min(0.8 * hp.k, W));
      core = { x: hp.sx, y: hp.sy, r: coreR, lens: coreR * 3.4 };
    }
    var pi = palIdx();
    var bigGlow = glow("big" + pi, rgba(pal.star, 0.5), "rgba(255,255,255,.9)");
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var p = proj(s.x, s.y, s.z);
      if (p.sx < -6 || p.sx > W + 6 || p.sy < -6 || p.sy > H + 6) { continue; }
      var twk = 0.72 + 0.28 * Math.sin(T * 2.4 + s.tw);
      var a = Math.max(0.05, Math.min(1, (1.7 - s.z / 60) * s.b)) * twk;
      if (core) {
        var dx = p.sx - core.x, dy = p.sy - core.y;
        var ds = Math.sqrt(dx * dx + dy * dy);
        if (ds < core.r * 0.9) { continue; }
        if (ds < core.lens) {
          var k2 = 1 - (core.lens - ds) / core.lens * 0.55;
          p.sx = core.x + dx * k2 / Math.max(ds, 0.001) * ds;
          p.sy = core.y + dy * k2 / Math.max(ds, 0.001) * ds;
        }
      }
      if (s.big && s.z < 46) {
        var gz = Math.max(8, 30 * FOC / s.z / FOC * 10);
        var gsz = Math.max(10, 260 / s.z);
        g.globalAlpha = a * 0.55;
        g.drawImage(bigGlow, p.sx - gsz / 2, p.sy - gsz / 2, gsz, gsz);
      }
      g.globalAlpha = a;
      g.fillStyle = pal.star;
      var r2 = s.big ? 2.2 : (s.z < 22 ? 1.8 : 1.2);
      g.fillRect(p.sx - r2 / 2, p.sy - r2 / 2, r2, r2);
    }
    g.globalAlpha = 1;
  }

  function drawHole(hp, prox) {
    var coreR = Math.max(3, Math.min(0.8 * hp.k, W * 0.7));
    var ringR = coreR * 2.2 * (1 + prox * 0.65);
    var breathe = 1 + Math.sin(T * 1.6) * 0.02 * (1 + prox * 2);
    ringR *= breathe;

    /* 外部辉光 */
    g.globalCompositeOperation = "screen";
    var gl = glow("hole" + palIdx(), rgba(pal.ring, 0.4), rgba(pal.ring, 0.55));
    var gsz = ringR * 5.2;
    g.globalAlpha = 0.35 + prox * 0.4;
    g.drawImage(gl, hp.sx - gsz / 2, hp.sy - gsz / 2, gsz, gsz);
    g.globalCompositeOperation = "source-over";
    g.globalAlpha = 1;

    /* 光子环 */
    g.save();
    g.translate(hp.sx, hp.sy);
    if (prox > 0.25) { g.rotate(Math.sin(T * 0.7) * 0.16 * prox); }
    g.strokeStyle = pal.ring;
    g.lineWidth = Math.max(1.4, coreR * 0.42);
    g.globalAlpha = 0.9;
    g.beginPath(); g.arc(0, 0, ringR, 0, Math.PI * 2); g.stroke();
    /* 热斑 */
    g.globalAlpha = 0.85;
    g.strokeStyle = "#ffffff";
    g.lineWidth = Math.max(1, coreR * 0.16);
    var ha = T * 1.9 % (Math.PI * 2);
    g.beginPath(); g.arc(0, 0, ringR, ha, ha + 1.1); g.stroke();
    /* 引力弯折副环 */
    if (prox > 0.2) {
      g.globalAlpha = (prox - 0.2) * 0.7;
      g.strokeStyle = pal.n2;
      g.lineWidth = Math.max(1, coreR * 0.2);
      g.save(); g.scale(1, 0.8); g.rotate(T * 0.4);
      g.beginPath(); g.arc(0, 0, ringR * 1.45, 0, Math.PI * 2); g.stroke();
      g.restore();
    }
    g.restore();

    /* 视界 */
    g.globalAlpha = 1;
    g.fillStyle = pal.bg1;
    g.beginPath(); g.arc(hp.sx, hp.sy, coreR, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#000";
    g.beginPath(); g.arc(hp.sx, hp.sy, coreR * 0.82, 0, Math.PI * 2); g.fill();

    /* 潮汐流：贴近时向内拉的短弧 */
    if (prox > 0.45) {
      g.strokeStyle = pal.ring; g.globalAlpha = (prox - 0.45) * 1.1;
      g.lineWidth = 1.4;
      for (var i = 0; i < 7; i++) {
        var ang = T * 1.3 + i * 0.9;
        var r1 = ringR * (1.5 + 0.25 * Math.sin(T * 2 + i));
        g.beginPath();
        g.arc(hp.sx, hp.sy, r1, ang, ang + 0.5);
        g.stroke();
      }
      g.globalAlpha = 1;
    }
  }

  function drawDust(hp) {
    var x0 = CX, y0 = H * 0.9;
    var mx = (x0 + hp.sx) / 2 + Math.sin(T * 0.8) * 18;
    var my = (y0 + hp.sy) / 2 - 24;
    var n = 16;
    g.globalCompositeOperation = "screen";
    var dg = glow("dust" + palIdx(), rgba(pal.ring, 0.8), "#fff");
    for (var i = 0; i < n; i++) {
      var u = (i / n + T * 0.11) % 1;
      var a1 = 1 - u, b1 = u;
      var px = a1 * a1 * x0 + 2 * a1 * b1 * mx + b1 * b1 * hp.sx;
      var py = a1 * a1 * y0 + 2 * a1 * b1 * my + b1 * b1 * hp.sy;
      var sz = 3 + u * 6;
      var al = 0.16 + 0.5 * u;
      if (u > 0.82) { al *= Math.max(0, (1 - u) / 0.18); }
      g.globalAlpha = al;
      g.drawImage(dg, px - sz / 2, py - sz / 2, sz, sz);
    }
    g.globalCompositeOperation = "source-over";
    g.globalAlpha = 1;
  }

  /* ---------------- REBORN / 跃迁 ---------------- */
  function flash(on, ms) {
    var el = document.getElementById("white");
    if (on) { el.className = "on"; } else { el.className = ""; }
    if (ms) { setTimeout(function () { el.className = ""; }, ms); }
  }
  function doReborn() {
    if (rebornBusy) { return; }
    rebornBusy = true;
    STATS.r += 1; saveStats(); updStats();
    flash(true);
    A.buzz([40, 60, 90]);
    setTimeout(function () {
      uniNo += 1;
      newUniverse();
      var rb = document.getElementById("rb");
      document.getElementById("rbSub").textContent = "第 " + uniNo + " 宇宙 · " + (fractal ? "折叠的星空" : pal.name);
      rb.className = "on";
      flash(false);
      setTimeout(function () { rb.className = ""; rebornBusy = false; }, 1700);
    }, 420);
  }
  function doWarp() {
    if (rebornBusy || !running) { return; }
    rebornBusy = true;
    STATS.j += 1; saveStats(); updStats();
    flash(true);
    A.buzz(24);
    setTimeout(function () {
      uniNo += 1;
      newUniverse();
      flash(false);
      A.toast("已跃迁 · " + (fractal ? "撞进了" + pal.name + "般的折叠星域" : pal.name));
      rebornBusy = false;
    }, 340);
  }

  /* ---------------- 深空低频声 ---------------- */
  function startDrone() {
    try {
      if (!actx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) { return false; }
        actx = new AC();
        agn = actx.createGain(); agn.gain.value = 0.0001;
        var lp = actx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 220;
        osc1 = actx.createOscillator(); osc1.type = "sine"; osc1.frequency.value = 54;
        osc2 = actx.createOscillator(); osc2.type = "sine"; osc2.frequency.value = 57.3;
        osc1.connect(lp); osc2.connect(lp); lp.connect(agn); agn.connect(actx.destination);
        osc1.start(); osc2.start();
      }
      agn.gain.setTargetAtTime(0.05, actx.currentTime, 0.6);
      if (actx.resume) { actx.resume(); }
      return true;
    } catch (e) { return false; }
  }
  function stopDrone() {
    try { if (agn) { agn.gain.setTargetAtTime(0.0001, actx.currentTime, 0.3); } } catch (e) {}
  }
  function updateDrone() {
    try {
      var prox = Math.max(0, Math.min(1, 1 - dist / 60));
      osc1.frequency.setTargetAtTime(54 - prox * 20, actx.currentTime, 0.4);
      osc2.frequency.setTargetAtTime(57.3 - prox * 21, actx.currentTime, 0.4);
      agn.gain.setTargetAtTime(0.05 + prox * 0.09, actx.currentTime, 0.5);
    } catch (e) {}
  }

  /* ---------------- 输入 ---------------- */
  var drag = null;
  cv.addEventListener("touchstart", function (e) {
    if (!running) { return; }
    if (e.touches && e.touches.length) {
      var t0 = e.touches[0];
      drag = { x: t0.clientX, y: t0.clientY, moved: 0, t0: Date.now(), lp: setTimeout(onLongPress, 680) };
      throttle = true;
      regTap(Date.now());
    }
  }, { passive: true });
  cv.addEventListener("touchmove", function (e) {
    if (!drag || !e.touches || !e.touches.length) { return; }
    var t0 = e.touches[0];
    var dx = t0.clientX - drag.x;
    drag.moved += Math.abs(dx);
    drag.x = t0.clientX;
    steerT = Math.max(-1, Math.min(1, steerT + dx / (W * 0.24)));
    if (drag.moved > 10 && drag.lp) { clearTimeout(drag.lp); drag.lp = null; }
  }, { passive: true });
  cv.addEventListener("touchend", function () {
    if (drag && drag.lp) { clearTimeout(drag.lp); }
    drag = null; throttle = false;
  });
  cv.addEventListener("touchcancel", function () {
    if (drag && drag.lp) { clearTimeout(drag.lp); }
    drag = null; throttle = false;
  });

  function onLongPress() {
    drag.lp = null;
    steerT = 0;
    doWarp();
  }

  /* 桌面调试：鼠标 */
  var mdown = false;
  cv.addEventListener("mousedown", function (e) { if (!running) { return; } mdown = true; throttle = true; regTap(Date.now()); });
  cv.addEventListener("mousemove", function (e) {
    if (!mdown) { return; }
    steerT = Math.max(-1, Math.min(1, steerT + e.movementX / (W * 0.24)));
  });
  window.addEventListener("mouseup", function () { mdown = false; throttle = false; });

  /* 彩蛋：2.5 秒内连点 5 下 */
  function regTap(now) {
    tapTimes.push(now);
    while (tapTimes.length && now - tapTimes[0] > 2500) { tapTimes.shift(); }
    if (tapTimes.length >= 5) {
      tapTimes = [];
      unlockEgg();
    }
  }
  function unlockEgg() {
    var first = !STATS.e;
    STATS.e = 1; saveStats(); updStats();
    if (first) { A.toast("彩蛋解锁 · 玫瑰之心已加入轮换"); }
    var ew = document.getElementById("eggWord");
    ew.className = "egg on";
    setTimeout(function () { ew.className = "egg"; }, 3200);
    if (!rebornBusy && palIdx() !== 4) {
      rebornBusy = true;
      flash(true);
      setTimeout(function () {
        newUniverse(4, false);
        flash(false);
        rebornBusy = false;
      }, 300);
    }
  }

  function hold(node, down, up) {
    node.addEventListener("touchstart", function (e) { e.preventDefault(); down(); }, { passive: false });
    node.addEventListener("touchend", function (e) { e.preventDefault(); up(); }, { passive: false });
    node.addEventListener("mousedown", down);
    window.addEventListener("mouseup", up);
  }
  hold(document.getElementById("btnBoost"), function () { throttle = true; }, function () { throttle = false; });
  var warpTimer = null;
  var btnWarp = document.getElementById("btnWarp");
  hold(btnWarp, function () {
    if (!btnWarp.className.match(/charging/)) {
      btnWarp.className = "warp charging";
      warpTimer = setTimeout(function () { btnWarp.className = "warp"; doWarp(); }, 620);
    }
  }, function () {
    if (warpTimer) { clearTimeout(warpTimer); warpTimer = null; }
    btnWarp.className = "warp";
  });

  A.tap(document.getElementById("btnSnd"), function () {
    if (!sndOn) {
      if (startDrone()) {
        sndOn = true;
        document.getElementById("sndTip").textContent = "声音 开";
        A.toast("深空低频已开启 · 越靠近黑洞越沉");
      } else { A.toast("当前环境不支持音频"); }
    } else {
      sndOn = false; stopDrone();
      document.getElementById("sndTip").textContent = "声音 关";
    }
  });

  /* ---------------- 持久化 ---------------- */
  function saveStats() { A.setJSON("ur_stats", STATS); }
  function loadStats(cb) {
    A.getJSON("ur_stats", { j: 0, r: 0, c: null, e: 0 }, function (s) {
      STATS = s || { j: 0, r: 0, c: null, e: 0 };
      if (!STATS.j) { STATS.j = 0; }
      if (!STATS.r) { STATS.r = 0; }
      if (!STATS.e) { STATS.e = 0; }
      cb(STATS);
    });
  }
  function updStats() {
    var el = document.getElementById("uStats");
    var bs = document.getElementById("bootStats");
    var line = "跃迁 " + STATS.j + " · REBORN ×" + STATS.r + " · 最近 " + (STATS.c == null ? "—" : STATS.c) + " 单位";
    if (el) { el.textContent = line; }
    if (bs) {
      bs.textContent = "漫游档案：跃迁 " + STATS.j + " 次 · REBORN " + STATS.r + " 次 · 距黑洞最近 " +
        (STATS.c == null ? "—" : STATS.c + " 单位") + " · 已解锁宇宙 " + (4 + (STATS.e ? 1 : 0)) + "/5";
    }
  }

  /* ---------------- 结果卡 ---------------- */
  function drawCardTo(c, x2) {
    var CW = c.width, CH = c.height;
    var gd = x2.createLinearGradient(0, 0, 0, CH);
    gd.addColorStop(0, pal.bg0); gd.addColorStop(1, pal.bg1);
    x2.fillStyle = gd; x2.fillRect(0, 0, CW, CH);

    var pi = palIdx();
    x2.globalCompositeOperation = "screen";
    var blobs = [[0.22, 0.2, 900, 0.5, 0], [0.8, 0.42, 700, 0.34, 1], [0.5, 0.12, 620, 0.3, 2]];
    for (var i = 0; i < blobs.length; i++) {
      var b = blobs[i];
      var spr = blobFor(pi, b[4]);
      x2.globalAlpha = b[3];
      x2.drawImage(spr, b[0] * CW - b[2] / 2, b[1] * CH - b[2] / 2, b[2], b[2]);
    }
    x2.globalCompositeOperation = "source-over";
    x2.globalAlpha = 1;
    for (var s = 0; s < 260; s++) {
      x2.globalAlpha = 0.2 + Math.random() * 0.7;
      x2.fillStyle = pal.star;
      var rr = Math.random() < 0.12 ? 2.6 : 1.4;
      x2.fillRect(Math.random() * CW, Math.random() * CH, rr, rr);
    }
    x2.globalAlpha = 1;

    /* 黑洞 */
    var hx = CW / 2, hy = CH * 0.52, coreR = 96, ringR = 228;
    var gl = glow("hole" + pi, rgba(pal.ring, 0.4), rgba(pal.ring, 0.55));
    x2.globalCompositeOperation = "screen";
    x2.globalAlpha = 0.55;
    x2.drawImage(gl, hx - ringR * 2.6, hy - ringR * 2.6, ringR * 5.2, ringR * 5.2);
    x2.globalCompositeOperation = "source-over";
    x2.globalAlpha = 1;
    x2.strokeStyle = pal.ring; x2.lineWidth = 34; x2.globalAlpha = 0.95;
    x2.beginPath(); x2.arc(hx, hy, ringR, 0, Math.PI * 2); x2.stroke();
    x2.strokeStyle = "#fff"; x2.lineWidth = 12;
    x2.beginPath(); x2.arc(hx, hy, ringR, 0.6, 1.8); x2.stroke();
    x2.globalAlpha = 1;
    x2.fillStyle = pal.bg1;
    x2.beginPath(); x2.arc(hx, hy, coreR, 0, Math.PI * 2); x2.fill();
    x2.fillStyle = "#000";
    x2.beginPath(); x2.arc(hx, hy, coreR * 0.82, 0, Math.PI * 2); x2.fill();

    x2.textAlign = "center";
    x2.fillStyle = "rgba(232,230,242,.55)";
    x2.font = "400 26px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("C O S M I C   R O M A N C E", CW / 2, 108);
    x2.fillStyle = "#f2eeff";
    x2.font = "700 78px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("宇宙浪漫", CW / 2, 196);
    x2.fillStyle = pal.ring;
    x2.font = "600 32px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("落入爱的黑洞", CW / 2, 248);

    x2.fillStyle = "#ffffff";
    x2.font = "700 56px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("REBORN × " + STATS.r, CW / 2, 956);
    x2.fillStyle = "rgba(232,230,242,.8)";
    x2.font = "400 28px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("跃迁 " + STATS.j + " 次 · 距黑洞最近 " + (STATS.c == null ? "—" : STATS.c) + " 世界单位", CW / 2, 1014);
    x2.fillText("已解锁宇宙 " + (4 + (STATS.e ? 1 : 0)) + "/5 · 当前：" + (fractal ? "折叠星域 · " : "") + pal.name, CW / 2, 1058);

    x2.fillStyle = "rgba(255,255,255,.14)";
    x2.fillRect(140, 1116, CW - 280, 2);
    x2.fillStyle = "rgba(232,230,242,.6)";
    x2.font = "400 26px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("没有关卡，没有终点，", CW / 2, 1180);
    x2.fillText("是一段可以一直待着的宇宙。", CW / 2, 1224);
    x2.fillStyle = "rgba(232,230,242,.34)";
    x2.font = "400 21px -apple-system,'PingFang SC',sans-serif";
    x2.fillText("宇宙浪漫 · 陪你放空的口袋宇宙", CW / 2, 1330);
  }

  A.tap(document.getElementById("btnSave"), function () {
    if (!running) { A.toast("先开始漫游"); return; }
    A.card(1080, 1440, drawCardTo, function (u) { A.saveImage(u, "宇宙已存入相册"); });
  });
  A.tap(document.getElementById("btnPost"), function () {
    if (!running) { A.toast("先开始漫游"); return; }
    A.card(1080, 1440, drawCardTo, function (u) {
      A.postNote({
        title: "宇宙浪漫：落入爱的黑洞",
        content: "被爱的黑洞吸进去，又在另一个宇宙醒来 —— REBORN × " + STATS.r + "。\n" +
          "星云是算出来的，黑洞弯折光线，一串星尘替你指路。\n" +
          "距黑洞最近的一次：" + (STATS.c == null ? "还没敢靠近" : STATS.c + " 世界单位") + "。\n" +
          "没有关卡、没有终点，睡前放空，或盯着发呆。\n\n" +
          "#宇宙浪漫 #治愈系 #星空 #解压 #小工具",
        image: u
      });
    });
  });

  /* ---------------- 启动 ---------------- */
  function layout() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
    g.setTransform(DPR, 0, 0, DPR, 0, 0);
    CX = W / 2; CY = H * 0.42; FOC = H * 0.92;
  }
  document.getElementById("btnGo").addEventListener("click", function () {
    document.getElementById("boot").className = "hide";
    running = true;
    lastT = 0;
  });
  loadStats(function () { updStats(); });
  genFractal();
  initStars();
  layout();
  newUniverse(0, false);
  updStats();
  window.addEventListener("resize", function () { layout(); });
  window.addEventListener("orientationchange", function () { setTimeout(layout, 260); });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
      throttle = false;
    } else {
      lastT = 0;
      if (!rafId) { rafId = requestAnimationFrame(loop); }
    }
  });
  rafId = requestAnimationFrame(loop);
  window.UR = {
    warp: doWarp, egg: unlockEgg,
    near: function (d) { hole.z = d || 12; hole.x = 0; hole.y = 0; },
    pal: function (i, fr) { newUniverse(i, fr); },
    stat: function () { return { st: running, pal: palIdx(), fr: fractal, d: Math.round(dist), u: uniNo }; }
  };
})();
