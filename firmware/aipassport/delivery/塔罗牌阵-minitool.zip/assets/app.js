/* 塔罗牌阵 app — 三张牌阵 / 凯尔特十字（ES2017，事件委托，真牌面）
 * v2：78 张韦特真牌面上卡（固件 TRT1 分区解码导出）；UI 重做；
 *     凯尔特十字「阻碍」牌改为沉到底层 + 微偏移，解决压牌点不开。
 */
(function () {
  "use strict";
  var ARC_NAME = { M: "大阿尔卡纳", W: "权杖", C: "圣杯", S: "宝剑", P: "星币" };
  var THREE = [
    { name: "过去", role: "这件事的来路：它是怎么一步步走到今天的。翻开的牌告诉你，哪些因已经种下。" },
    { name: "现在", role: "眼下的局面：你正站在什么位置，手里握着什么牌。这是整个牌阵的重心。" },
    { name: "未来", role: "往前的走向：按现在的势头走下去，事情大概率会朝这个方向演化。" }
  ];
  var CELTIC = [
    { name: "现状", role: "眼下的核心局面，整件事的起点。先读这张，再往四周展开。", fx: 0.235, fy: 0.352, z: 3 },
    { name: "阻碍", role: "横在面前的力量：可能是一个人、一种情绪，也可能是你自己的某个习惯。", fx: 0.235, fy: 0.352, cross: true, z: 2, dx: -7, dy: 6, scale: 0.94 },
    { name: "根基", role: "藏在局面底下的东西：这件事真正的出发点，或你未必意识到的基础。", fx: 0.040, fy: 0.352, z: 1 },
    { name: "过去", role: "正在退出你生活的影响，它塑造了现在，但已在松手。", fx: 0.235, fy: 0.610, z: 1 },
    { name: "意识", role: "你心里清楚的目标：你自认为想要的、正在努力够的方向。", fx: 0.235, fy: 0.094, z: 1 },
    { name: "近未来", role: "接下来一步的气氛：不是结局，是马上要遇到的东西。", fx: 0.430, fy: 0.352, z: 1 },
    { name: "自我", role: "你自己在这件事里的姿态：你怎么看自己，就会怎么出手。", fx: 0.720, fy: 0.760, z: 1 },
    { name: "环境", role: "周围的人和事：家人、同事、环境氛围，它们都在给这件事施力。", fx: 0.720, fy: 0.562, z: 1 },
    { name: "希望与恐惧", role: "你最想要的和最怕的，常常是同一张牌的两面。", fx: 0.720, fy: 0.364, z: 1 },
    { name: "结果", role: "十张牌合起来看的落点：把前面九张串起来，再读这一张。", fx: 0.720, fy: 0.166, z: 1 }
  ];
  var SUIT_COLOR = { M: "#d8b46a", W: "#c9763e", C: "#5c7db8", S: "#9a9aa8", P: "#7da85c" };
  var state = { spread: "three", cards: null, spreadName: "" };
  var board = document.getElementById("board");
  var readingsEl = document.getElementById("readings");
  var CW = 62, CH = 104;
  var IMG_CACHE = {};

  /* 牌面地址 + 预载 */
  for (var ci = 0; ci < TAROT_CARDS.length; ci++) {
    TAROT_CARDS[ci].img = "./assets/cards/" + TAROT_CARDS[ci].id + ".webp";
  }
  (function preload() {
    for (var i = 0; i < TAROT_CARDS.length; i++) {
      var im = new Image();
      im.src = TAROT_CARDS[i].img;
      IMG_CACHE[TAROT_CARDS[i].id] = im;
    }
  })();

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
  function imgOf(card) { return IMG_CACHE[card.id]; }

  function draw() {
    var deck = TAROT_CARDS.slice();
    for (var i = deck.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)); var t = deck[i]; deck[i] = deck[j]; deck[j] = t;
    }
    var defs = state.spread === "three" ? THREE : CELTIC;
    state.cards = [];
    for (var k = 0; k < defs.length; k++) {
      state.cards.push({ def: defs[k], card: deck[k], reversed: Math.random() < 0.32, flipped: false });
    }
    state.spreadName = state.spread === "three" ? "三张牌阵" : "凯尔特十字";
    renderBoard(true);
    readingsEl.innerHTML = '<div class="reading"><h3>先翻牌</h3><p style="color:var(--mute);font-size:12.5px;line-height:1.9">点牌翻开。' +
      (state.spread === "three" ? "三张全翻开后，这里会出现每一位的完整解读。" : "十张全翻开后，这里会出现每一位的完整解读。") + "</p></div>";
    document.getElementById("btn-cast").textContent = "重 新 洗 牌";
    document.getElementById("board-hint").textContent = state.spread === "three" ? "点牌翻开 · 翻完自动出解读" : "点牌翻开（竖压横的那张从边缘点）· 翻完自动出解读";
    var lg = document.getElementById("legend");
    if (state.spread === "celtic") {
      lg.className = "legend";
      document.getElementById("legend-rows").innerHTML = CELTIC.map(function (d, i) {
        return '<div class="lrow"><b>' + (i + 1) + "</b><i>" + esc(d.name) + "</i><span>" + esc(d.role) + "</span></div>";
      }).join("");
    } else { lg.className = "legend hide"; }
  }

  function renderBoard(animate) {
    var defs = state.spread === "three" ? THREE : CELTIC;
    var W = board.clientWidth || 340;
    var bw, bh;
    if (state.spread === "three") { bw = W; bh = Math.round(W * 0.5); }
    else { bw = W; bh = Math.round(W * 1.5); }
    board.style.height = bh + "px";
    var html = "";
    state.cards.forEach(function (c, i) {
      var sx, sy, rot = 0, z = 1, sc = 1;
      if (state.spread === "three") {
        CW = Math.round(bw * 0.26); CH = Math.round(CW / 0.5696);
        sx = (bw - 3 * CW - 2 * 14) / 2 + i * (CW + 14);
        sy = (bh - CH) / 2 - 10;
      } else {
        CW = Math.round(bw * 0.165); CH = Math.round(CW / 0.5696);
        sc = c.def.scale || 1;
        sx = c.def.fx * bw + (c.def.dx || 0);
        sy = c.def.fy * bh + (c.def.dy || 0);
        if (c.def.cross) rot = 90;
        z = c.def.z || 1;
      }
      if (!c._pos) c._pos = { sx: sx, sy: sy, rot: rot };
      /* 位置标签（三张阵：牌上方；凯尔特：序号角标） */
      if (state.spread === "three") {
        html += '<div class="plabel" style="left:' + sx + "px;top:" + (sy - 20) + "px;width:" + CW + 'px">' + esc(c.def.name) + "</div>";
      }
      var wpx = Math.round(CW * sc), hpx = Math.round(CH * sc);
      var im2 = imgOf(c.card);
      var imgHtml = im2 ? '<img src="' + c.card.img + '" alt="' + esc(c.card.name) + '">' : "";
      html += '<div class="tcard' + (c.reversed ? " reversed" : "") + '" data-i="' + i + '" style="left:' + sx + "px;top:" + sy +
        "px;width:" + wpx + "px;height:" + hpx + "px;z-index:" + z + '">' +
        (state.spread === "celtic" ? '<span class="num">' + (i + 1) + "</span>" : "") +
        '<div class="inner">' +
        '<div class="face back"><div class="bem"><span>✦</span></div></div>' +
        '<div class="face frontc">' + imgHtml +
        (c.reversed ? '<span class="rev">逆位</span>' : "") +
        '<div class="nm">' + esc(c.card.name) + "</div></div>" +
        "</div></div>";
    });
    board.innerHTML = html;
    if (animate) {
      var els = board.querySelectorAll(".tcard");
      for (var i = 0; i < els.length; i++) {
        (function (el, i2) {
          el.style.opacity = "0";
          el.style.transform = "translateY(22px) scale(.94)";
          setTimeout(function () {
            el.style.transition = "opacity .35s, transform .35s";
            el.style.opacity = "1";
            el.style.transform = "";
          }, 55 * i2 + 30);
        })(els[i], i);
      }
    }
  }

  function flip(i) {
    var c = state.cards[i];
    if (c.flipped) { zoomCard(i); return; }
    c.flipped = true;
    var el = board.querySelector('.tcard[data-i="' + i + '"]');
    if (el) el.classList.add("flipped");
    AAPT.buzz(12);
    var flippedAll = state.cards.every(function (x) { return x.flipped; });
    if (flippedAll) setTimeout(showReadings, 420);
    recordHistory(c);
  }

  function recordHistory(c) {
    AAPT.pushHistory("tt_casts", {
      s: state.spreadName, n: c.card.name, r: c.reversed ? "逆" : "正", ts: Date.now()
    }, 10, function () { renderHistory(); });
  }

  function readingFor(c) {
    var card = c.card;
    var kw = c.reversed ? card.rev : card.up;
    var txt = c.reversed ? (card.revTxt || card.rev) : (card.upTxt || card.up);
    return { kw: kw, txt: txt };
  }

  function showReadings() {
    var html = "";
    state.cards.forEach(function (c, i) {
      var r = readingFor(c);
      html += '<div class="reading"><div class="rh">' +
        '<img src="' + c.card.img + '" alt="">' +
        '<div class="rt"><h3>' + (i + 1) + " · " + esc(c.def.name) + " — " + esc(c.card.name) + (c.reversed ? "（逆位）" : "") + "</h3>" +
        '<div class="pos">' + esc(c.card.en) + " · " + esc(ARC_NAME[c.card.arc] || "") + "</div></div></div>" +
        '<div class="kw">' + esc(r.kw) + "</div><p>" + esc(r.txt) + "</p>" +
        '<div class="role">' + esc(c.def.role) + "</div></div>";
    });
    html += '<div style="display:flex;margin-top:2px">' +
      '<button class="castbtn ghost" data-x="save" type="button" style="margin-right:8px">存 牌 阵 图</button>' +
      '<button class="castbtn ghost" data-x="post" type="button" style="margin-left:8px">发 笔 记</button></div>';
    readingsEl.innerHTML = html;
    setTimeout(function () { readingsEl.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60);
  }

  function zoomCard(i) {
    var c = state.cards[i], r = readingFor(c);
    var ov = document.createElement("div");
    ov.className = "zoom";
    ov.innerHTML = '<div class="zcard' + (c.reversed ? " rev" : "") + '"><img src="' + c.card.img + '" alt=""><div class="nm">' + esc(c.card.name) + "</div></div>" +
      '<div class="zmeta"><div class="n">' + esc(c.card.name) + (c.reversed ? " · 逆位" : "") + '</div>' +
      '<div class="en">' + esc(c.card.en) + " · " + esc(ARC_NAME[c.card.arc] || "") + "</div>" +
      '<div class="kw">' + esc(r.kw) + "</div></div>" +
      '<div class="zt">' + esc(r.txt) + "</div>" +
      '<div class="zr">' + esc(c.def.name) + "：" + esc(c.def.role) + "</div>" +
      '<button class="zclose" type="button">关 闭</button>';
    document.body.appendChild(ov);
    ov.addEventListener("click", function (ev) {
      if (ev.target === ov || (ev.target.closest && ev.target.closest("button"))) ov.parentNode.removeChild(ov);
    });
  }

  function renderHistory() {
    var el = document.getElementById("his");
    AAPT.getJSON("tt_casts", [], function (a) {
      el.innerHTML = (a && a.length) ? a.map(function (r) {
        return '<div class="hrow"><span>' + esc(r.s) + '</span><span>' + esc(r.n) + "（" + esc(r.r) + "位）</span></div>";
      }).join("") : '<div class="hrow" style="justify-content:center">还没有抽过牌</div>';
    });
  }

  /* ---------- 牌阵分享图（真牌面上图） ---------- */
  function drawBoardCard(forPost) {
    var c = document.createElement("canvas"); c.width = 1080; c.height = 1440;
    var x = c.getContext("2d");
    var g = x.createLinearGradient(0, 0, 0, 1440);
    g.addColorStop(0, "#241829"); g.addColorStop(1, "#100a12");
    x.fillStyle = g; x.fillRect(0, 0, 1080, 1440);
    x.strokeStyle = "rgba(216,180,106,.5)"; x.lineWidth = 3; x.strokeRect(30, 30, 1020, 1380);
    x.textAlign = "center";
    x.fillStyle = "#f0d9a8"; x.font = '900 46px "Songti SC","STSong",serif';
    x.fillText("塔罗牌阵 · " + state.spreadName, 540, 132);
    x.fillStyle = "#9b8b93"; x.font = '23px "Songti SC",serif';
    x.fillText("七十八张伟特真牌 · 心理自我参考", 540, 178);
    var defs = state.spread === "three" ? THREE : CELTIC;
    if (state.spread === "three") {
      var CW2 = 240, CH2 = 422, gap = 40, startY = 300;
      for (var i = 0; i < 3; i++) {
        drawMini(x, state.cards[i], 540 - (CW2 * 1.5 + gap) + i * (CW2 + gap), startY, CW2, CH2, defs[i].name, i + 1);
      }
    } else {
      var PW = 168, PH = 295;
      var pos = [
        [300, 560, 0], [300, 560, 1], [70, 560, 0], [300, 900, 0], [300, 220, 0], [530, 560, 0],
        [800, 1030, 0], [800, 740, 0], [800, 450, 0], [800, 160, 0]
      ];
      for (var j = 0; j < 10; j++) {
        drawMini(x, state.cards[j], pos[j][0], pos[j][1], PW, PH, defs[j].name, j + 1, pos[j][2] === 1);
      }
    }
    x.fillStyle = "#9b8b93"; x.font = '22px "Songti SC",serif';
    x.fillText("AI PASSPORT · 塔罗牌阵 · 心理仪式参考", 540, 1332);
    if (forPost) x.fillText("搜索「塔罗牌阵」同款小工具", 540, 1374);
    return c.toDataURL("image/png");
  }
  function drawMini(x, c, px, py, w, h, label, no, cross) {
    x.save();
    if (cross) { x.translate(px + w / 2, py + h / 2); x.rotate(Math.PI / 2); x.translate(-(px + w / 2), -(py + h / 2)); }
    if (c.reversed) { x.translate(px + w / 2, py + h / 2); x.rotate(Math.PI); x.translate(-(px + w / 2), -(py + h / 2)); }
    var im = imgOf(c.card);
    if (im && im.complete && im.naturalWidth) {
      x.drawImage(im, px, py, w, h);
    } else {
      x.fillStyle = "#2a1c30"; x.fillRect(px, py, w, h);
    }
    x.strokeStyle = "rgba(216,180,106,.85)"; x.lineWidth = 2.5;
    var r = 10;
    x.beginPath();
    x.moveTo(px + r, py); x.arcTo(px + w, py, px + w, py + h, r); x.arcTo(px + w, py + h, px, py + h, r);
    x.arcTo(px, py + h, px, py, r); x.arcTo(px, py, px + w, py, r); x.closePath();
    x.stroke();
    if (c.reversed) {
      x.fillStyle = "rgba(201,107,134,.92)";
      roundRect(x, px + 6, py + 6, 58, 30, 6); x.fill();
      x.fillStyle = "#fff"; x.font = '700 19px "Songti SC",serif'; x.textAlign = "center";
      x.fillText("逆位", px + 35, py + 27);
    }
    x.restore();
    x.fillStyle = "#d8b46a"; x.font = '700 24px "Songti SC",serif'; x.textAlign = "center";
    x.fillText(no + " " + label, px + w / 2, py - 14);
  }
  function roundRect(x, a, b, w, h, r) {
    x.beginPath();
    x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r);
    x.arcTo(a, b + h, a, b, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath();
  }

  /* ---------- 事件 ---------- */
  document.querySelector(".spreads").addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("button[data-s]");
    if (!b) return;
    state.spread = b.getAttribute("data-s");
    var bs = document.querySelectorAll(".spreads button");
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle("on", bs[i] === b);
    AAPT.buzz(8);
    board.innerHTML = ""; readingsEl.innerHTML = "";
    document.getElementById("btn-cast").textContent = "洗 牌 · 抽 牌";
  });
  document.getElementById("btn-cast").addEventListener("click", function () { AAPT.buzz(14); draw(); });
  board.addEventListener("click", function (ev) {
    var t = ev.target.closest && ev.target.closest(".tcard");
    if (t) flip(parseInt(t.getAttribute("data-i"), 10));
  });
  readingsEl.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("button[data-x]");
    if (!b) return;
    var op = b.getAttribute("data-x");
    AAPT.buzz(10);
    if (op === "save") AAPT.saveImage(drawBoardCard(false), "牌阵图已存入相册");
    else if (op === "post") {
      var lines = state.cards.map(function (c, i) { return (i + 1) + " " + c.def.name + "：" + c.card.name + (c.reversed ? "（逆位）" : ""); }).join("；");
      AAPT.postNote({
        title: ("塔罗牌阵 · " + state.spreadName).slice(0, 20),
        content: "抽了一次" + state.spreadName + "：" + lines + "。（伟特体系通用解读，心理自我参考）",
        image: drawBoardCard(true)
      });
    }
  });
  window.addEventListener("resize", function () { if (state.cards) renderBoard(false); });
  renderHistory();
})();
